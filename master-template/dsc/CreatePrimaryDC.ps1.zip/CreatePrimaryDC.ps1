﻿configuration CreatePrimaryDC
{
   param
   (
        [String]$DiskSize = "Small-4GB",
        [String]$DisksizeGB = 4,

        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [String]$DomainNetbiosName, 
        
        [Parameter(Mandatory)]
        [String]$DNSServer, 
       
        [String]$DataDisks,

        [Parameter(Mandatory)]
        [String]$sites,

        [Parameter(Mandatory)]
        [String]$ForestMode,       

        [Parameter(Mandatory=$true)]
		[ValidateNotNullorEmpty()]
        [PSCredential]
        $DomainAdminCredential,
              
        [PSCredential]
        $AzureShareCredential,
       
        [String]$SourcePath,

        [Parameter(Mandatory=$true)]
        [Int]$RetryCount,
        
        [Parameter(Mandatory=$true)]
        [Int]$RetryIntervalSec,

        [Boolean]$RebootNodeIfNeeded = $true,
        [String]$ActionAfterReboot = "ContinueConfiguration",
        [String]$ConfigurationModeFrequencyMins = 15,
        [String]$ConfigurationMode = "ApplyAndMonitor",
        [String]$RefreshMode = "Push",
        [String]$RefreshFrequencyMins  = 30

    )
    # import DSC modules 
    Import-DscResource -ModuleName xActiveDirectory
    Import-DscResource -ModuleName xDnsServer      
    Import-DSCResource -ModuleName StorageDsc
    Import-DscResource -ModuleName XSmbShare
    Import-DscResource -ModuleName xPendingReboot
    Import-DscResource -ModuleName NetworkingDsc 
    Import-DscResource -ModuleName PSDesiredStateConfiguration

    # get computer network interface 
    $Interface=Get-NetAdapter|Where Name -Like "Ethernet*"|Select-Object -First 1
    $InterfaceAlias=$($Interface.Name)
    
    Node localhost
    {
        # set local configuratiom manager settings 
        LocalConfigurationManager
        {
           RebootNodeIfNeeded = $RebootNodeIfNeeded
           ActionAfterReboot = $ActionAfterReboot            
           ConfigurationModeFrequencyMins = $ConfigurationModeFrequencyMins
           ConfigurationMode = $ConfigurationMode
           RefreshMode = $RefreshMode
           RefreshFrequencyMins = $RefreshFrequencyMins            
        }

        # Move DVD optical drive letter E to Z
        OpticalDiskDriveLetter MoveDiscDrive
        {
            DiskId      = 1
            DriveLetter = 'Z' # This value is ignored if absent
            Ensure      = 'Present'
        }
       
        # convert DataDisks Json string to array of objects
        $DataDisks = $DataDisks | ConvertFrom-Json        

        # loop each Datadisk information and mount to a letter in object
        $count = 2 # start with "2" ad "0" and "1" is for  C  and D that comes from WindowsServer Azure image 

        # if size eq small wait only one data disk
        if($DiskSize -ne "Default") {
            # wait for disk is mounted to vm and available   
            WaitForDisk DataDisk
            {
                DiskId = $count 
                RetryIntervalSec = $RetryIntervalSec
                RetryCount = $RetryCount
                #DependsOn  ="[OpticalDiskDriveLetter]MoveDiscDrive"
            }

            #$DependsOn = "[WaitForDisk]DataDisk"
        }

        $DisksizeGB  = [int64]$DisksizeGB * 1GB

        foreach ($datadisk in $DataDisks)
        {
            if($DiskSize -ne "Default") {
                # once disk number availabe, assign and format drive with all available sizes and assign a leter and label that comes from parameters.
                if(($DataDisks.Length -1 ) -eq $DataDisks.IndexOf($datadisk))
                {
                    Disk $datadisk.letter
                    {
                        FSLabel = $datadisk.name
                        DiskId = $count 
                        DriveLetter = $datadisk.letter                  
                        #DependsOn = $DependsOn
                    }
                }                
                else {
                    Disk $datadisk.letter
                    {
                        FSLabel = $datadisk.name
                        DiskId = $count 
                        DriveLetter = $datadisk.letter
                        Size = $DisksizeGB
                        #DependsOn = $DependsOn
                    }
                }
                #$DependsOn = "[Disk]" + $datadisk.letter

                $DisksizeGB += 0.01GB
            }
            else{
                # wait for disk is mounted to vm and available   
                WaitForDisk $datadisk.name
                {
                    DiskId = $count 
                    RetryIntervalSec = $RetryIntervalSec
                    RetryCount = $RetryCount
                    #DependsOn  ="[OpticalDiskDriveLetter]MoveDiscDrive"                   
                }
                # once disk number availabe, assign and format drive with all available sizes and assign a leter and label that comes from parameters.
                Disk $datadisk.letter
                {
                    FSLabel = $datadisk.name
                    DiskId = $count 
                    DriveLetter = $datadisk.letter
                    #DependsOn = "[WaitForDisk]"+$datadisk.name
                }
                $count ++
            }
        }  
          
        # install features for Domain Controllers
        # active directory windows features 
        @(
            "AD-Domain-Services",            
            "RSAT-ADDS-Tools"                                         
        ) | ForEach-Object -Process {
               WindowsFeature "Feature-$_"
               {
                   Ensure = "Present"
                   Name = $_
                   
               }
        }
        
        # dns windows features 
        @(
            "DNS",
            "RSAT-Dns-Server"
        ) | ForEach-Object -Process {
                WindowsFeature "Feature-$_"
                {
                    Ensure = "Present"
                    Name = $_
                   
                }
        }

        # modify computer dns 
        DnsServerAddress DnsServerAddress
        {
            Address        = $DNSServer
            InterfaceAlias = $InterfaceAlias
            AddressFamily  = 'IPv4'
        }
     
        # create domain first controller
        xADDomain FirstDS
        {
            DomainName      = $DomainName
            #DomainNetbiosName = $DomainNetbiosName
            DomainAdministratorCredential = $DomainAdminCredential
            SafemodeAdministratorPassword = $DomainAdminCredential
            ForestMode                    = $ForestMode
            DatabasePath = "E:\NTDS"
            LogPath = "E:\NTDS"
            SysvolPath = "E:\SYSVOL"
            #DependsOn = "[WindowsFeature]Feature-AD-Domain-Services", "[Disk]E"                       
        }
        
        # create sites and subnets to primary domain
        $sites = $sites | ConvertFrom-Json 
   
        foreach ($site in $sites)         
        {
            xADReplicationSite $site.name 
            {
                Ensure = "Present"
                Name = $site.name
                RenameDefaultFirstSiteName = $true 
                #DependsOn="[xADDomain]FirstDS"        
            }
            
            xADReplicationSubnet $site.name
            {
                Ensure = "Present"
                Name   = $site.prefix
                Site  = $site.name
                #DependsOn = "[xADReplicationSite]"+$site.name
            }
        }
   
        # create site links to primary domain
        foreach ($site in $sites)         
        {
            if($site.sitelink -ne $null)
            {
                $linkname = $site.sitelink.Replace(',', ' to ')
                $name = $site.name
                $sitelink  = $site.sitelink.Split(',')
   
                Script "ADReplicationSiteLink-$name"
                {
                    SetScript = {
                        New-ADReplicationSiteLink -Name $using:linkname -SitesIncluded $using:sitelink -Cost 100 -ReplicationFrequencyInMinutes 15 -InterSiteTransportProtocol IP
                        Get-ADReplicationSiteLink -filter {Name -eq "DEFAULTIPSITELINK"} | Remove-ADReplicationSiteLink
                    }
   
                    TestScript = { 
                        $site = Get-ADReplicationSiteLink -filter {Name -eq $using:linkname}
                        if($site -eq $null) 
                        {
                            return $false
                        }
                        else 
                        {
                            return $true
                        }
                    }
                    GetScript = { $null }
                    #DependsOn = "[xADReplicationSite]" + $site.name
                }
            }
        }

        # Domain Trust
        

        if ($DomainName -eq 'DomainDmz.com'){

            xDnsServerForwarder SetForwarders
            {
                IsSingleInstance = 'Yes'
                IPAddresses = '10.0.0.5', '10.0.4.5'
            }

            $TargetDomainAdminCredential  =  New-Object -TypeName PSCredential -ArgumentList "Domain\domainadmin", $DomainAdminCredential.Password

            xADDomainTrust trust
            {
                Ensure                              = 'Present'
                SourceDomainName                    = $DomainName
                TargetDomainName                    = "Domain.com" #$TargetDomain
                TargetDomainAdministratorCredential = $TargetDomainAdminCredential
                TrustDirection                      = 'Outbound'
                TrustType                           = 'External'
              
            }
        }
        

        # AD Accounts 
        # $userAccounts = @(
        #     "svcSql",
        #     "svcSPSetup",
        #     "svcSPFarm",
        #     "svcSPWebApp",
        #     "svcSPSvcApp",
        #     "svcSPCrawl",
        #     "svcSPUPSync",
        #     "svcSPSuperUser",
        #     "svcSPReader"
        # )

        # $userAccounts | ForEach-Object -Process {
        #     xADUser "User-$_"
        #     {
        #         DomainName = $domainName
        #         DomainAdministratorCredential = $DomainAdminCredential 
        #         UserName = $_ 
        #         Password = $ServiceAccountCredential 
        #         Ensure = "Present" 
        #         DependsOn = "[xWaitForADDomain]DscForestWait" 
        #     }
        # }
        
        # copy share files from Azure to F:\share
        if($AzureShareCredential -ne $null -And $SourcePath -ne $null) {
            
            File DirectoryCopy
            {
                Ensure = "Present"  # You can also set Ensure to "Absent"
                Type = "Directory" # Default is "File".
                Recurse = $true # Ensure presence of subdirectories, too
                SourcePath = $SourcePath
                DestinationPath = "F:\SHARE"
                Credential = $AzureShareCredential
                Force =  $true
                MatchSource =  $true
                #DependsOn = "[xADDomain]FirstDS", "[Disk]F"
            }

            # share folder to everyone as read access
            xSmbShare FileShare
            {
                Ensure = "Present"
                Name   = "Share"
                Path = "F:\SHARE"
                Description = "This is a test SMB Share"
                ReadAccess = 'Everyone'                   
                #DependsOn = "[File]DirectoryCopy"                   
            }
        }
        
         # File SQLAGBackup
         File SQLAGBackup
         {
             Ensure = "Present"  # You can also set Ensure to "Absent"
             Type = "Directory" # Default is "File". 
             DestinationPath = "F:\SQLAGBackup"
             Credential = $DomainAdminCredential
             #Force =  $true
             #DependsOn = "[Disk]F"
         }
 
         # xSmbShare MySMBShare
         xSmbShare SQLAGBackup
         {
             Ensure = "Present"
             Name   = "SQLAGBackUp"
             Path = "F:\SQLAGBackUp"
             Description = "This is for SQL AG temporary recovery/initilize location"
             FullAccess = 'Everyone'       
             #DependsOn = "[File]SQLAGBackup"                   
         }

   }
}