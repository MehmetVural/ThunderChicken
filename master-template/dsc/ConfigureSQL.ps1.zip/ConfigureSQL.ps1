Configuration ConfigureSQL { 
    param
    (

        [Parameter(Mandatory=$true)]
		[ValidateNotNullorEmpty()]
        [PSCredential]$SqlInstallCredential,

        [Parameter()]
        [ValidateNotNullorEmpty()]
        [System.Management.Automation.PSCredential]
        $SqlAdministratorCredential = $SqlInstallCredential,

        [Parameter()]
        [ValidateNotNullorEmpty()]
        [System.Management.Automation.PSCredential]
        $SqlServiceCredential = $SqlInstallCredential,

        [Parameter()]
        [ValidateNotNullorEmpty()]
        [System.Management.Automation.PSCredential]
        $SqlAgentServiceCredential = $SqlInstallCredential,

        [Parameter(Mandatory=$true)]
		[ValidateNotNullorEmpty()]
        [PSCredential]$DomainAdminCredential,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]    
        [String]$Nodes,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]    
        [String]$Config,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]    
        [String]$ServerName,        

        [Boolean]$RebootNodeIfNeeded = $true,
        [String]$ActionAfterReboot = "ContinueConfiguration",
        [String]$ConfigurationModeFrequencyMins = 15,
        [String]$ConfigurationMode = "ApplyAndAutoCorrect",
        [String]$RefreshMode = "Push",
        [String]$RefreshFrequencyMins  = 30
    
   )
    Import-DscResource -ModuleName SqlServerDsc
    Import-DscResource -ModuleName StorageDsc
    Import-DscResource -ModuleName xCredSSP
    Import-DscResource -ModuleName xFailOverCluster -ModuleVersion 1.9.0.0
    Import-DscResource -ModuleName NetworkingDsc
    Import-DscResource -ModuleName PSDesiredStateConfiguration

    $ConfigData = $ConfigData | ConvertFrom-Json

    Node localhost  {

         # set local configuratiom manager settings 
         LocalConfigurationManager
         {
             RebootNodeIfNeeded = $RebootNodeIfNeeded
             ActionAfterReboot = $ActionAfterReboot            
             ConfigurationModeFrequencyMins = $ConfigurationModeFrequencyMins
             ConfigurationMode = $ConfigurationMode
             RefreshMode = $RefreshMode
             RefreshFrequencyMins = $RefreshFrequencyMins            
         }

        # Convert Json string to Hashtable
        $Nodes = $Nodes | ConvertFrom-Json 
        $Config = $Config | ConvertFrom-Json 

        $Node = $Nodes.Nodes.Where{$_.Name -eq $ServerName} 

        $ClusterIPAddress = $Nodes.NonNodeData.ClusterIPAddress
        $ClusterName      = $Nodes.NonNodeData.ClusterName
        $ClusterNodes = @();
        # $SQLConfiguration.Nodes.Where{$_.Role -eq "Primary"}       

        $Nodes.Nodes.foreach({
            $ClusterNodes += $_.Name
        });

        xCredSSP CredSSPServer
        {
            Ensure = 'Present'
            Role = 'Server'
        }

        xCredSSP CredSSPClient
        {
            Ensure = 'Present'
            Role = 'Client'
            DelegateComputers = '*.Domain.com'
        }
        
        @(
            "Failover-clustering",            
            "RSAT-Clustering-PowerShell",
            "RSAT-Clustering-CmdInterface",
            "RSAT-Clustering-Mgmt"
        ) | ForEach-Object -Process {
            WindowsFeature "Feature-$_"
            {
                Ensure = "Present"
                Name = $_
            }
        }  

        if ( $Node.Role -eq 'Primary' )      
        { 
          
           WaitForAll ClusterFeature
           {
                ResourceName = '[WindowsFeature]Feature-RSAT-Clustering-CmdInterface'
                NodeName = $Node.Name
                RetryIntervalSec = 30
                RetryCount = 10
                PsDscRunAsCredential = $SqlInstallCredential
           }
        
           Script CreateCluster
            {
                SetScript = {

                    $ClusterService = Get-Service "ClusSvc"
                    
                    If($ClusterService) 
                    {
                        New-Cluster $using:ClusterName -Node $using:ClusterNodes -StaticAddress $using:ClusterIPAddress -NoStorage -AdministrativeAccessPoint Dns
                    }
                    #Get-Cluster -Name 'mc21'  | Add-ClusterNode -Name "VS222"
                    #Get-Cluster -Name MyCl1 | Add-ClusterNode -Name node3

                }
                TestScript = {  
                                $ClusterService = Get-Service "ClusSvc"

                                 If($ClusterService) 
                                 {
                                    if($ClusterService.StartType -ne "Disabled")
                                    {
                                        if(Get-Cluster) {
                                        return $true
                                        }
                                        else{return $true}
                                    }
                                    else
                                    {
                                        return $false
                                    }                                 
                                 }
                                 else {return $true}
                
                }

                GetScript = { $null }
                DependsOn        =  '[WindowsFeature]Feature-Failover-clustering','[WindowsFeature]Feature-RSAT-Clustering-CmdInterface'
                PsDscRunAsCredential  =  $SqlInstallCredential
               
            }
        }

        MountImage ISO
        {
            ImagePath   =  $Config.SQLInstalISO
            DriveLetter = 'S'
            Ensure = "Present"
        }

        WaitForVolume WaitForISO
        {
            DriveLetter      = 'S'
            RetryIntervalSec = 100
            RetryCount       = 10
        }

        File DirectoryCopy
        {
            Ensure = "Present" # Ensure the directory is Present on the target node.
            Type = "Directory" # The default is File.
            Recurse = $true # Recursively copy all subdirectories.
            SourcePath = "S:\"
            DestinationPath = "C:\INSTALL\SQL2016"
            DependsOn         = "[WaitForVolume]WaitForISO"
        }

       Registry DisableIPv6
       {
           Key       = 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip6\Parameters'
           ValueName = 'DisabledComponents'
           ValueData = 'ff'
           ValueType = 'Dword'
           Hex       = $true
           Ensure    = 'Present'
       }
        
       Registry DisableLoopBackCheck 
            {
            Ensure = "Present"
            Key = "HKLM:\System\CurrentControlSet\Control\Lsa"
            ValueName = "DisableLoopbackCheck"
            ValueData = "1"
            ValueType = "Dword"
       }
         
        #endregion Install SQL Server
        Firewall SQLEngineFirewallRule
        {
            Name         = 'SQLDatabaseEngine'
            DisplayName  = 'SQL Server Database Engine'
            Group        = 'SQL Server Rules'
            Ensure       = 'Present'
            Action       = 'Allow'
            Enabled      = 'True'
            Profile      = ('Domain', 'Private')
            Direction    = 'Inbound'
            LocalPort    = ('1433', '1434')
            Protocol     = 'TCP'
            Description  = 'SQL Database engine exception'
        }    
        
        #endregion Install SQL Server
        Firewall SQLEngineFailoverCluster
        {
            Name         = 'SQLFailover'
            DisplayName  = 'SQL Failover Sync'
            Group        = "SQL Server Rules"
            Ensure       = 'Present'
            Action       = 'Allow'
            Enabled      = 'True'
            Profile      = ('Domain', 'Private')
            Direction    = 'Inbound'
            LocalPort    = ('5022', '5022')
            Protocol     = 'TCP'
            Description  = 'SQL Failover Port'
        }        
        
        WaitForAll Cluster
        {
           NodeName = $Nodes.Nodes.Where{$_.Role -eq "Primary"}.Name
           ResourceName = "[Script]CreateCluster"
           PsDscRunAsCredential = $SqlAdministratorCredential
           RetryCount = 1440
           RetryIntervalSec = 5
        }

        #region Install SQL Server
        SqlSetup 'InstallDefaultInstance'
        {
            InstanceName         = $Config.InstanceName 
            #Features             = 'SQLENGINE,AS'
            Features             = 'SQLENGINE,FULLTEXT,AS,RS'
            #ProductKey           = '' 
            SQLCollation         = 'SQL_Latin1_General_CP1_CI_AS'
            SQLSvcAccount        = $SqlServiceCredential
            AgtSvcAccount        = $SqlAgentServiceCredential             
            AgtSvcStartupType    = "Automatic"
            SqlSvcStartupType    = "Automatic"
            SQLSysAdminAccounts  = $SqlAdministratorCredential.UserName
            InstallSharedDir     = 'C:\Program Files\Microsoft SQL Server'
            InstallSharedWOWDir  = 'C:\Program Files (x86)\Microsoft SQL Server'
            InstanceDir          = 'C:\Program Files\Microsoft SQL Server'
            InstallSQLDataDir    = 'E:\Data'
            SQLUserDBDir         = 'E:\Data'
            SQLUserDBLogDir      = 'F:\Logs'
            SQLTempDBDir         = 'G:\Data'
            SQLTempDBLogDir      = 'G:\Logs'
            SQLBackupDir         = 'H:\Backup'              
            SourcePath           =  "C:\INSTALL\SQL2016"
            UpdateEnabled        = 'False'
            ForceReboot          = $true 
            ASServerMode         = 'TABULAR'
            ASConfigDir          = 'E:\MSOLAP\Config'
            ASDataDir            = 'E:\MSOLAP\Data'
            ASLogDir             = 'F:\MSOLAP\Log'
            ASBackupDir          = 'H:\MSOLAP\Backup'
            ASTempDir            = 'G:\MSOLAP\Data'
            AsSvcStartupType     = "Automatic"
            FTSvcAccount         =  $SqlServiceCredential
            ASSvcAccount         =  $SqlServiceCredential
            RSSvcAccount         =  $SqlServiceCredential
            RsSvcStartupType     =  "Automatic"
            BrowserSvcStartupType = "Automatic"
            PsDscRunAsCredential = $SqlInstallCredential   
            DependsOn         = "[File]DirectoryCopy", "[Firewall]SQLEngineFirewallRule"
       }
          
       SqlServerLogin DomainAdminLogin
       {
          Name = 'LAB\Domain Admins'
          LoginType = 'WindowsGroup'
          ServerName = $ServerName
          InstanceName = 'MSSQLSERVER' 
          DependsOn = "[SqlSetup]InstallDefaultInstance"
          PsDscRunAsCredential = $SqlAdministratorCredential
       }  
 
       SqlRS DefaultConfiguration
       {
           InstanceName         = $Config.InstanceName 
           DatabaseServerName   = $Node.Name
           DatabaseInstanceName = $Config.InstanceName 
           PsDscRunAsCredential = $SqlInstallCredential 
           DependsOn = "[SqlSetup]InstallDefaultInstance"
       }
       
       # Adding the required service account to allow the cluster to log into SQL
       SqlServerLogin AddNTServiceClusSvc
       {
           Ensure               = 'Present'
           Name                 = 'NT SERVICE\ClusSvc'
           LoginType            = 'WindowsUser'
           ServerName           = $Node.Name
           InstanceName         = $Config.InstanceName 
           PsDscRunAsCredential = $SqlAdministratorCredential
           DependsOn            = "[SqlSetup]InstallDefaultInstance", "[WindowsFeature]Feature-Failover-clustering"
       }

       # Add the required permissions to the cluster service login
       SqlServerPermission AddNTServiceClusSvcPermissions
       {
           Ensure               = 'Present'
           ServerName           = $Node.Name
           InstanceName         = $Config.InstanceName 
           Principal            = 'NT SERVICE\ClusSvc'
           Permission           = 'AlterAnyAvailabilityGroup', 'ViewServerState'
           PsDscRunAsCredential = $SqlAdministratorCredential
           DependsOn            = '[SqlServerLogin]AddNTServiceClusSvc'
       }

       SqlAlwaysOnService EnableHADR
       {
          Ensure               = 'Present'
          InstanceName         = $Config.InstanceName 
          ServerName           = $Node.Name
          PsDscRunAsCredential = $SqlAdministratorCredential
          DependsOn = "[SqlSetup]InstallDefaultInstance",  "[WindowsFeature]Feature-Failover-clustering",  "[WaitForAll]Cluster" 
       }

        # Create a DatabaseMirroring endpoint
       SqlServerEndpoint HADREndpoint
       {
          DependsOn = "[SqlSetup]InstallDefaultInstance", "[SqlAlwaysOnService]EnableHADR"
          EndPointName         = 'HADR'
          Ensure               = 'Present'
          Port                 = 5022
          ServerName           = $Node.Name
          InstanceName         = $Config.InstanceName 
          PsDscRunAsCredential = $SqlAdministratorCredential
       }

       # install Microsoft SQL Server Management Studio
       Package SQLStudio
       {
            Ensure = "Present"   
            Name = "Microsoft SQL Server Management Studio"
            Path = $Config.SQLManagementStudio2016Path          
            ProductId = $Config.SQLManagementStudio2016ProductId
            Arguments = "/install /passive /norestart"
            PsDscRunAsCredential = $SqlAdministratorCredential
            #LogPath = [string] 
            #DependsOn = "[SqlSetup]InstallDefaultInstance"            
       }

       if ( $Node.Role -eq 'Primary' ) 
       { 
            SqlDatabase CreateDatabase1
            {
                Ensure       = 'Present'
                Name         = "TestDB1"             
                ServerName   = $Node.Name
                InstanceName = $Config.InstanceName               
                PsDscRunAsCredential = $SqlAdministratorCredential   
                DependsOn    = "[SqlSetup]InstallDefaultInstance"
            }

            SqlDatabase CreateDatabase2
            {
                Ensure       = 'Present'
                Name         = "TestDB2"
                ServerName   = $Node.Name
                InstanceName = $Config.InstanceName               
                PsDscRunAsCredential = $SqlAdministratorCredential   
                DependsOn    = "[SqlSetup]InstallDefaultInstance"
            }

            SqlAG AddTestAG
            {
                Ensure               = 'Present'
                Name                 = 'TestAG'
                InstanceName         = $Config.InstanceName 
                ServerName           = $Node.Name
                
                AvailabilityMode              = "SynchronousCommit"
                BackupPriority                = 50
                ConnectionModeInPrimaryRole   = "AllowAllConnections"
                ConnectionModeInSecondaryRole = "AllowAllConnections"
                FailoverMode                  = "Automatic"
                EndpointHostName              = $Node.Name

                DependsOn            = '[SqlAlwaysOnService]EnableHADR', '[SqlServerEndpoint]HADREndpoint', '[SqlServerPermission]AddNTServiceClusSvcPermissions'
                PsDscRunAsCredential = $SqlAdministratorCredential
            }      
       }

       if ( $Node.Role -eq 'Secondary' ) 
       {
           #Secondary
           SqlWaitForAG WaitForAG
           {
               Name                  = 'TestAG'
               RetryCount            = 1440
               RetryIntervalSec      = 5
               DependsOn             =  "[SqlSetup]InstallDefaultInstance", "[SqlAlwaysOnService]EnableHADR"
           }

            # Add the availability group replica to the availability group
           SqlAGReplica AddReplica
           {
               Ensure                     = 'Present'
               Name                       = $Node.Name
               AvailabilityGroupName      = $Config.AvailabilityGroupName 
               ServerName                 = $Node.Name
               InstanceName               = $Config.InstanceName 
               ProcessOnlyOnActiveNode    = $true
               PrimaryReplicaServerName   = $Nodes.Nodes.Where{$_.Role -eq "Primary"}.Name
               PrimaryReplicaInstanceName = $Config.InstanceName 
               
               AvailabilityMode              = "SynchronousCommit"
               BackupPriority                = 50
               ConnectionModeInPrimaryRole   = "AllowAllConnections"
               ConnectionModeInSecondaryRole = "AllowAllConnections"
               FailoverMode                  = "Automatic"
               EndpointHostName              = $Node.Name
               DependsOn                  = '[SqlAlwaysOnService]EnableHADR', "[SqlWaitForAG]WaitForAG"
               PsDscRunAsCredential       = $SqlAdministratorCredential
           }        
       }
       if ( $Node.Role -eq 'Primary' )
       {
            WaitForAll Replica
            {
                ResourceName         = '[SqlAGReplica]AddReplica'
                NodeName             = $Nodes.Nodes.Where{$_.Role -eq "Secondary"}.Name
                RetryCount           = 1440
                RetryIntervalSec     = 5
                PsDscRunAsCredential = $SqlAdministratorCredential
            }

           SqlAGDatabase 'TestAGDatabaseMemberships'
            {
                Ensure                  = 'Present'
                AvailabilityGroupName   = $Config.AvailabilityGroupName 
                BackupPath              = $Config.SQLAGBackup
                DatabaseName            = 'TestDB*'
                InstanceName            = $Config.InstanceName 
                ServerName              = $Node.Name              
                #ProcessOnlyOnActiveNode = $true
                PsDscRunAsCredential    = $SqlAdministratorCredential
                DependsOn = "[SqlAG]AddTestAG", "[SqlAlwaysOnService]EnableHADR", "[WaitForAll]Replica"
            }    
       }

    }
}
 