
Configuration SQLSetup { 
    param
    (
        [Parameter(Mandatory = $true)]
        [ValidateNotNullorEmpty()]
        [System.Management.Automation.PSCredential]
        $SqlInstallCredential,

        [Parameter()]
        [ValidateNotNullorEmpty()]
        [System.Management.Automation.PSCredential]
        $SqlAdministratorCredential = $SqlInstallCredential,

        [Parameter()]
        [ValidateNotNullorEmpty()]
        [System.Management.Automation.PSCredential]
        $SqlServiceCredential = $SqlInstallCredential,

        [Parameter()]
        [ValidateNotNullorEmpty()]
        [System.Management.Automation.PSCredential]
        $SqlAgentServiceCredential = $SqlInstallCredential
    )

    #If(Get-Module )
    #Install-Module  SqlServerDsc
    #if (Get-Module -ListAvailable -Name SqlServerDsc)
    #{ Install-Module SqlServerDsc }

    Import-DscResource -ModuleName SqlServerDsc
    Import-DscResource -ModuleName StorageDsc
    Import-DscResource -ModuleName xCredSSP
    Import-DscResource -ModuleName xFailOverCluster -ModuleVersion 1.9.0.0
    Import-DscResource -ModuleName NetworkingDsc
    Import-DscResource -ModuleName PSDesiredStateConfiguration

    Node $AllNodes.NodeName  {

        
             
        xCredSSP CredSSPServer
        {
            Ensure = 'Present'
            Role = 'Server'
        }

        xCredSSP CredSSPClient
        {
            Ensure = 'Present'
            Role = 'Client'
            DelegateComputers = '*.Domain.com'
        }

        @(
            "Failover-clustering",            
            "RSAT-Clustering-PowerShell",
            "RSAT-Clustering-CmdInterface",
            "RSAT-Clustering-Mgmt"
        ) | ForEach-Object -Process {
            WindowsFeature "Feature-$_"
            {
                Ensure = "Present"
                Name = $_
            }
        }  

        if ( $Node.Role -eq 'FirstServerNode' )       
        {
          
          $ClusterName = $ConfigurationData.NonNodeData.ClusterName 
          #$ClusterNode = 'VS222'
           WaitForAll ClusterFeature
           {
                ResourceName = '[WindowsFeature]Feature-RSAT-Clustering-CmdInterface'
                NodeName = $Node.NodeName
                RetryIntervalSec = 30
                RetryCount = 10
                PsDscRunAsCredential = $SqlInstallCredential
           }
           
           $ClusterIPAddress = $ConfigurationData.NonNodeData.ClusterIPAddress
           $ClusterName      = $ConfigurationData.NonNodeData.ClusterName
           $ClusterNodes = @();
            
           $AllNodes.foreach({
            $ClusterNodes += $_.NodeName
           });

           Script CreateCluster
            {
                SetScript = {
                     
                                    
                    $ClusterService = Get-Service "ClusSvc"
                    
                    If($ClusterService) 
                    {
                        New-Cluster $using:ClusterName -Node $using:ClusterNodes -StaticAddress $using:ClusterIPAddress -NoStorage -AdministrativeAccessPoint Dns
                    }
                    #Get-Cluster -Name 'mc21'  | Add-ClusterNode -Name "VS222"
                    #Get-Cluster -Name MyCl1 | Add-ClusterNode -Name node3

                }
                TestScript = {  
                                $ClusterService = Get-Service "ClusSvc"

                                 If($ClusterService) 
                                 {
                                    if($ClusterService.StartType -ne "Disabled")
                                    {
                                        if(Get-Cluster) {
                                        return $true
                                        }
                                        else{return $true}
                                    }
                                    else
                                    {
                                        return $false
                                    }                                 
                                 }
                                 else {return $true}
                
                }

                GetScript = { $null }
                DependsOn        =  '[WindowsFeature]Feature-Failover-clustering','[WindowsFeature]Feature-RSAT-Clustering-CmdInterface'
                PsDscRunAsCredential  =  $SqlInstallCredential
               
            }
        }

         MountImage ISO
        {
            ImagePath   =  $ConfigurationData.NonNodeData.SQLInstalISO
            DriveLetter = 'S'
            Ensure = "Present"
        }

        WaitForVolume WaitForISO
        {
            DriveLetter      = 'S'
            RetryIntervalSec = 30
            RetryCount       = 10
        }

       Registry DisableIPv6
       {
           Key       = 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip6\Parameters'
           ValueName = 'DisabledComponents'
           ValueData = 'ff'
           ValueType = 'Dword'
           Hex       = $true
           Ensure    = 'Present'
       }
        
       Registry DisableLoopBackCheck 
            {
            Ensure = "Present"
            Key = "HKLM:\System\CurrentControlSet\Control\Lsa"
            ValueName = "DisableLoopbackCheck"
            ValueData = "1"
            ValueType = "Dword"
       }
         
        #endregion Install SQL Server
        Firewall SQLEngineFirewallRule
        {
            Name         = 'SQLDatabaseEngine'
            DisplayName  = 'SQL Server Database Engine'
            Group        = "SQL Server Rules"
            Ensure       = 'Present'
            Action       = 'Allow'
            Enabled      = 'True'
            Profile      = ('Domain', 'Private')
            Direction    = 'Inbound'
            LocalPort    = ('1433', '1434')
            Protocol     = 'TCP'
            Description  = 'SQL Database engine exception'
        }    
        
        #endregion Install SQL Server
        Firewall SQLEngineFailoverCluster
        {
            Name         = 'SQLFailover'
            DisplayName  = 'SQL Failover Sync'
            Group        = "SQL Server Rules"
            Ensure       = 'Present'
            Action       = 'Allow'
            Enabled      = 'True'
            Profile      = ('Domain', 'Private')
            Direction    = 'Inbound'
            LocalPort    = ('5022', '5022')
            Protocol     = 'TCP'
            Description  = 'SQL Failover Port'
        }        
        
        WaitForAll "Cluster"
        {
           NodeName = ( $AllNodes | Where-Object { $_.Role -eq 'FirstServerNode' } ).NodeName
           ResourceName = "[Script]CreateCluster"
           PsDscRunAsCredential = $SqlAdministratorCredential
           RetryCount = 1440
           RetryIntervalSec = 5
        }


        #region Install SQL Server
        SqlSetup 'InstallDefaultInstance'
        {
            InstanceName         = $ConfigurationData.NonNodeData.InstanceName 
            #Features             = 'SQLENGINE,AS'
            Features             = 'SQLENGINE,FULLTEXT,AS,RS'
            #ProductKey           = '' 
            SQLCollation         = 'SQL_Latin1_General_CP1_CI_AS'
            SQLSvcAccount        = $SqlServiceCredential
            AgtSvcAccount        = $SqlAgentServiceCredential             
            AgtSvcStartupType    = "Automatic"
            SqlSvcStartupType    = "Automatic"
            SQLSysAdminAccounts  = $SqlAdministratorCredential.UserName
            InstallSharedDir     = 'C:\Program Files\Microsoft SQL Server'
            InstallSharedWOWDir  = 'C:\Program Files (x86)\Microsoft SQL Server'
            InstanceDir          = 'C:\Program Files\Microsoft SQL Server'
            InstallSQLDataDir    = 'E:\Data'
            SQLUserDBDir         = 'E:\Data'
            SQLUserDBLogDir      = 'F:\Logs'
            SQLTempDBDir         = 'G:\Data'
            SQLTempDBLogDir      = 'G:\Logs'
            SQLBackupDir         = 'H:\Backup'              
            SourcePath           =  "S:\"
            UpdateEnabled        = 'False'
            ForceReboot          = $true 
            ASServerMode         = 'TABULAR'
            ASConfigDir          = 'E:\MSOLAP\Config'
            ASDataDir            = 'E:\MSOLAP\Data'
            ASLogDir             = 'F:\MSOLAP\Log'
            ASBackupDir          = 'H:\MSOLAP\Backup'
            ASTempDir            = 'G:\MSOLAP\Data'
            AsSvcStartupType     = "Automatic"
            FTSvcAccount         =  $SqlServiceCredential
            ASSvcAccount         =  $SqlServiceCredential
            RSSvcAccount         =  $SqlServiceCredential
            RsSvcStartupType     =  "Automatic"
            BrowserSvcStartupType = "Automatic"
            PsDscRunAsCredential = $SqlInstallCredential   
            DependsOn         = "[WaitForVolume]WaitForISO", "[Firewall]SQLEngineFirewallRule"
       }
          
       SqlServerLogin DomainAdminLogin
       {
          Name = 'LAB\Domain Admins'
          LoginType = 'WindowsGroup'
          ServerName = $Node.NodeName
          InstanceName = 'MSSQLSERVER' 
          DependsOn = "[SqlSetup]InstallDefaultInstance"
          PsDscRunAsCredential = $SqlAdministratorCredential           

       }  
 
       SqlRS DefaultConfiguration
       {
           InstanceName         = $ConfigurationData.NonNodeData.InstanceName 
           DatabaseServerName   = $Node.NodeName
           DatabaseInstanceName = $ConfigurationData.NonNodeData.InstanceName 
           PsDscRunAsCredential = $SqlInstallCredential 
           DependsOn = "[SqlSetup]InstallDefaultInstance"
       } 
       
       # Adding the required service account to allow the cluster to log into SQL
       SqlServerLogin AddNTServiceClusSvc
       {
           Ensure               = 'Present'
           Name                 = 'NT SERVICE\ClusSvc'
           LoginType            = 'WindowsUser'
           ServerName           = $Node.NodeName
           InstanceName         = $ConfigurationData.NonNodeData.InstanceName 
           PsDscRunAsCredential = $SqlAdministratorCredential
           DependsOn            = "[SqlSetup]InstallDefaultInstance", "[WindowsFeature]Feature-Failover-clustering"
       }

       # Add the required permissions to the cluster service login
       SqlServerPermission AddNTServiceClusSvcPermissions
       {          
           Ensure               = 'Present'
           ServerName           = $Node.NodeName
           InstanceName         = $ConfigurationData.NonNodeData.InstanceName 
           Principal            = 'NT SERVICE\ClusSvc'
           Permission           = 'AlterAnyAvailabilityGroup', 'ViewServerState'
           PsDscRunAsCredential = $SqlAdministratorCredential
           DependsOn            = '[SqlServerLogin]AddNTServiceClusSvc'
       }

       SqlAlwaysOnService EnableHADR
       {
          Ensure               = 'Present'
          InstanceName         = $ConfigurationData.NonNodeData.InstanceName 
          ServerName           = $Node.NodeName
          PsDscRunAsCredential = $SqlAdministratorCredential
          DependsOn = "[SqlSetup]InstallDefaultInstance",  "[WindowsFeature]Feature-Failover-clustering",  "[WaitForAll]Cluster" 
       }

        # Create a DatabaseMirroring endpoint
       SqlServerEndpoint HADREndpoint
       {
          DependsOn = "[SqlSetup]InstallDefaultInstance", "[SqlAlwaysOnService]EnableHADR"
          EndPointName         = 'HADR'
          Ensure               = 'Present'
          Port                 = 5022
          ServerName           = $Node.NodeName
          InstanceName         = $ConfigurationData.NonNodeData.InstanceName 
          PsDscRunAsCredential = $SqlAdministratorCredential
       }
        

       # install Microsoft SQL Server Management Studio
       Package [string] #ResourceName
       {
            Ensure = "Present"   
            Name = "Microsoft SQL Server Management Studio"
            Path = $ConfigurationData.NonNodeData.SQLManagementStudio2016Path          
            ProductId = $ConfigurationData.NonNodeData.SQLManagementStudio2016ProductId
            Arguments = "/install /passive /norestart"
            PsDscRunAsCredential = $SqlAdministratorCredential
            #LogPath = [string] 
            #DependsOn = "[SqlSetup]InstallDefaultInstance"            
       }

       if ( $Node.Role -eq 'FirstServerNode' )
       {
         
            SqlDatabase CreateDatabase1
            {
                Ensure       = 'Present'
                Name         = "TestDB1"             
                ServerName   = $Node.NodeName
                InstanceName = $ConfigurationData.NonNodeData.InstanceName               
                PsDscRunAsCredential = $SqlAdministratorCredential   
                DependsOn    = "[SqlSetup]InstallDefaultInstance"
            }

            SqlDatabase CreateDatabase2
            {
                Ensure       = 'Present'
                Name         = "TestDB2"
                ServerName   = $Node.NodeName
                InstanceName = $ConfigurationData.NonNodeData.InstanceName               
                PsDscRunAsCredential = $SqlAdministratorCredential   
                DependsOn    = "[SqlSetup]InstallDefaultInstance"
            }

            SqlAG AddTestAG
            {
                Ensure               = 'Present'
                Name                 = 'TestAG'
                InstanceName         = $ConfigurationData.NonNodeData.InstanceName 
                ServerName           = $Node.NodeName
                
                AvailabilityMode              = "SynchronousCommit"
                BackupPriority                = 50
                ConnectionModeInPrimaryRole   = "AllowAllConnections"
                ConnectionModeInSecondaryRole = "AllowAllConnections"
                FailoverMode                  = "Automatic"
                EndpointHostName              = $Node.NodeName

                DependsOn            = '[SqlAlwaysOnService]EnableHADR', '[SqlServerEndpoint]HADREndpoint', '[SqlServerPermission]AddNTServiceClusSvcPermissions'
                PsDscRunAsCredential = $SqlAdministratorCredential
            }       
                   
       }

       if ( $Node.Role -eq 'AdditionalServerNode' )       
       {
           #AdditionalServerNode
           SqlWaitForAG WaitForAG
           {
               Name                  = 'TestAG'
               RetryIntervalSec      = 10
               RetryCount            = 60
               DependsOn             =  "[SqlSetup]InstallDefaultInstance", "[SqlAlwaysOnService]EnableHADR"
           }

            # Add the availability group replica to the availability group
           SqlAGReplica AddReplica
           {
               Ensure                     = 'Present'
               Name                       = $Node.NodeName
               AvailabilityGroupName      = $ConfigurationData.NonNodeData.AvailabilityGroupName 
               ServerName                 = $Node.NodeName
               InstanceName               = $ConfigurationData.NonNodeData.InstanceName 
               ProcessOnlyOnActiveNode    = $true
               PrimaryReplicaServerName   = ( $AllNodes | Where-Object { $_.Role -eq 'FirstServerNode' } ).NodeName
               PrimaryReplicaInstanceName = $ConfigurationData.NonNodeData.InstanceName 
               
               AvailabilityMode              = "SynchronousCommit"
               BackupPriority                = 50
               ConnectionModeInPrimaryRole   = "AllowAllConnections"
               ConnectionModeInSecondaryRole = "AllowAllConnections"
               FailoverMode                  = "Automatic"
               EndpointHostName              = $Node.NodeName

               DependsOn                  = '[SqlAlwaysOnService]EnableHADR', "[SqlWaitForAG]WaitForAG"
               PsDscRunAsCredential       = $SqlAdministratorCredential


           }        
       }
       if ( $Node.Role -eq 'FirstServerNode' )
       {
            WaitForAll Replica
            {
                ResourceName = '[SqlAGReplica]AddReplica'
                NodeName = ( $AllNodes | Where-Object { $_.Role -eq 'AdditionalServerNode' } ).NodeName
                RetryIntervalSec = 10
                RetryCount = 50
                PsDscRunAsCredential = $SqlAdministratorCredential
            }

           SqlAGDatabase 'TestAGDatabaseMemberships'
            {
                Ensure                  = 'Present'
                AvailabilityGroupName   = $ConfigurationData.NonNodeData.AvailabilityGroupName 
                BackupPath              = $ConfigurationData.NonNodeData.SQLAGBackup
                DatabaseName            = 'TestDB*'
                InstanceName            = $ConfigurationData.NonNodeData.InstanceName 
                ServerName              = $Node.NodeName               
                #ProcessOnlyOnActiveNode = $true
                PsDscRunAsCredential    = $SqlAdministratorCredential
                DependsOn = "[SqlAG]AddTestAG", "[SqlAlwaysOnService]EnableHADR", "[WaitForAll]Replica"
            }    
       }
    }
}
 