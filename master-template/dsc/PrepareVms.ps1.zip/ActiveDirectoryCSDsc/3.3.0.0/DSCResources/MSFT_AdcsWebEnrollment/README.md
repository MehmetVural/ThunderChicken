# Description

This resource can be used to install the ADCS Web Enrollment service after the
feature has been installed on the server.
Using this DSC Resource to configure an ADCS Certificate Authority assumes that
the ```ADCS-Web-Enrollment``` feature has already been installed.
For more information on Web Enrollment services, see [this article on TechNet](https://technet.microsoft.com/en-us/library/cc732517.aspx).
