﻿try {
    Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope LocalMachine -Force -ErrorAction SilentlyContinue 
   
}
catch 
{
  Write-Verbose "Successfully Updated"  
}


configuration PrepareVms
{
   param
   (
        [String]$DiskSize = "Small-4GB",
        [String]$DisksizeGB = 4,

        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [String]$DNSServer,

        [Boolean]$joinDomain = $false,
        
        [string]$ServiceName,
        [string]$ServerName,      
        [String]$ServerIP, 
        [String]$ServerSite, 

        [string]$ConfigData,
        
        #[Parameter(Mandatory=$true)]
		#[ValidateNotNullorEmpty()]
        #[PSCredential]$UserAdminCredential,

        #[Parameter(Mandatory=$true)]
		#[ValidateNotNullorEmpty()]
        #[PSCredential]$LocalAdminCredential,
        
        [Parameter(Mandatory=$true)]
		[ValidateNotNullorEmpty()]
        [PSCredential]$InstallCredential,

        [Parameter(Mandatory=$true)]
		[ValidateNotNullorEmpty()]
        [PSCredential]$DomainAdminCredential,        

        [string]$DataDisks,

        [Parameter()]
        $enterpriseGithubUsername,
        
        [Parameter()]
        $enterpriseGithubToken,

        [Parameter(Mandatory=$true)]
        [Int]$RetryCount,

        [Parameter(Mandatory=$true)]
        [Int]$RetryIntervalSec,

        [Boolean]$RebootNodeIfNeeded = $true,
        [String]$ActionAfterReboot = "ContinueConfiguration",
        [String]$ConfigurationModeFrequencyMins = 15,
        [String]$ConfigurationMode = "ApplyAndAutoCorrect",
        [String]$RefreshMode = "Push",
        [String]$RefreshFrequencyMins  = 30
    )


    # import DSC modules 
    Import-DscResource -ModuleName xActiveDirectory
    Import-DscResource -ModuleName ComputerManagementDsc  
    Import-DscResource -ModuleName PackageManagement 
    
    Import-DscResource -ModuleName xCredSSP
    Import-DscResource -ModuleName SqlServerDsc
    Import-DSCResource -ModuleName StorageDsc
    Import-DscResource -ModuleName xPendingReboot
    Import-DscResource -ModuleName NetworkingDsc
    Import-DscResource -ModuleName xDnsServer
    Import-DscResource -ModuleName PSDesiredStateConfiguration    

    # get network adapter interface name 
    $Interface=Get-NetAdapter|Where Name -Like "Ethernet*"|Select-Object -First 1
    $InterfaceAlias=$($Interface.Name)
    
    Node localhost
    {
        # set local configuratiom manager settings 
        LocalConfigurationManager
        {
            RebootNodeIfNeeded = $RebootNodeIfNeeded
            ActionAfterReboot = $ActionAfterReboot            
            ConfigurationModeFrequencyMins = $ConfigurationModeFrequencyMins
            ConfigurationMode = $ConfigurationMode
            RefreshMode = $RefreshMode
            RefreshFrequencyMins = $RefreshFrequencyMins            
        }

        <#
        xCredSSP CredSSPServer
        {
            Ensure = 'Present'
            Role = 'Server'
        }

        xCredSSP CredSSPClient
        {
            Ensure = 'Present'
            Role = 'Client'
            DelegateComputers = '*.Domain.com'
        }     
      
        #>
        if($joinDomain){ 
            # change DNS server address to subnet DNS address
            DnsServerAddress  DnsServerAddress
            {
                Address        = $DNSServer
                InterfaceAlias = $InterfaceAlias
                AddressFamily  = 'IPv4'                  
            }   
        
            $FarmTask = "[DnsServerAddress]DnsServerAddress" 
        }

        if(-Not $joinDomain)
        {
          
            Script SetWSMAN
            {
                SetScript = {
                   try {
                    Set-item wsman:\localhost\Client\TrustedHosts -value "*.domain.com" -ErrorAction SilentlyContinue 
                    Set-NetFirewallRule –Name "WINRM-HTTP-In-TCP-PUBLIC" –RemoteAddress Any
                   }
                   catch {
                    Write-Verbose "Something went wrong during setting Set-Item WSMAN "
                   }
                }
    
                TestScript = {                                 
                  return $false
                }
                GetScript = { $null }                
            }
    
            $FarmTask = "[Script]SetWSMAN"  

            <# 
            User LocalUserA
            {
                Ensure      = "Present"  # To ensure the user account does not exist, set Ensure to "Absent"
                UserName    =  $UserAdminCredential.UserName
                Password    =  $UserAdminCredential  # This needs to be a credential object
                Description = 'User created by DSC'
                PasswordNeverExpires = $true
                PasswordChangeNotAllowed = $true
                #PsDscRunAsCredential =  $LocalAdminCredential 
                DependsOn   =  $FarmTask 

            }            

            $FarmTask = "[User]LocalUserA"
            
            Group AddUserAToLocalAdminGroup {
                GroupName            = 'Administrators'
                Ensure               = 'Present'                
                MembersToInclude     = "user_a"
                Credential           =  $LocalAdminCredential 
                DependsOn            = $FarmTask             
            }
            $FarmTask = "[Group]AddUserAToLocalAdminGroup"
            #>
       
        }

        ## JumpBox Settings
        #### if Workstation Aka JumbBox         
        if($env:ComputerName -eq "JumpBox") 
        { 
            Script SetWSMANJumpbox
            {
                SetScript = {
                   try {
                    Set-item wsman:\localhost\Client\TrustedHosts -value "*" -ErrorAction SilentlyContinue 
                   }
                   catch {
                    Write-Verbose "Something went wrong during setting Set-Item WSMAN "
                   }
                }
    
                TestScript = {                                 
                  return $false
                }
                GetScript = { $null }                
            }
    
            $FarmTask = "[Script]SetWSMANJumpbox"  

            <# 
            # install RSAT tools  for jumbBoox            
            @(
                "RSAT-ADDS-Tools" ,
                "RSAT-AD-PowerShell",
                "RSAT-DNS-Server",
                "RSAT-DHCP"                                    
            ) | ForEach-Object -Process {
               WindowsFeature "Feature-$_"
               {
                   Ensure = "Present"
                   Name = $_                   
               }
            }
            #>           
            <#
            PackageManagementSource SourceRepository
            {
                Ensure      = "Present"
                Name        = "MyNuget"
                ProviderName= "Nuget"
                SourceLocation   = "https://api.nuget.org/v3/"
                InstallationPolicy ="Trusted"
            }
            
            PackageManagementSource PSGallery
            {
                Ensure          = "Present"
                Name            = "psgallery"
                ProviderName    = "PowerShellGet"
                SourceLocation   = "https://www.powershellgallery.com/api/v2/"
                InstallationPolicy ="Trusted"
            }
           #>
            <# 
            PackageManagement NugetPackage
            {
                Ensure               = "Present"
                Name                 = "JQuery"
                AdditionalParameters = "$env:HomeDrive\nuget"
                RequiredVersion      = "2.0.1"
                DependsOn            = "[PackageManagementSource]SourceRepository"
            }
        
            PackageManagement PSModule
            {
                Ensure               = "Present"
                Name                 = "gistprovider"
                Source               = "PSGallery"
                DependsOn            = "[PackageManagementSource]PSGallery"
            }
            #>


            $packages = @(
                "vscode",                
                #"nodejs",
                "git",                
                "Git-Credential-Manager-for-Windows",
                "poshgit",
                "pester",
                "vscode-powershell",
                "googlechrome",
                "rsat"
                 #,"sql-server-management-studio"
            )

            $packageProviderName = "ChocolateyGet"
            Script DevSetup
            {
                SetScript = {
                    try {
                        Set-PSRepository -Name PSGallery -InstallationPolicy Trusted -ErrorAction SilentlyContinue
                        Install-PackageProvider -Name $using:packageProviderName -ErrorAction SilentlyContinue              
                        Install-PackageProvider "NuGet"  -Force -MinimumVersion 2.8 | Out-Null
                        #-ErrorAction SilentlyContinue # -RequiredVersion 2.8.5.201
                            
                        Import-PackageProvider -Name $using:packageProviderName              
                            
                        $using:packages | ForEach-Object -Process {
                                If(-Not (Get-Package -Name $_ -ProviderName $using:packageProviderName -ErrorAction SilentlyContinue)) 
                                {                        
                                Install-Package -Name $_ -ProviderName $using:packageProviderName -Confirm:$false -Force
                                }                                       
                        }
                    }
                    catch {
                        Write-Verbose "Could NOT install packages, will try again in next run"
                    }
                }

                TestScript = {                     
                        $var = $true
                        try {
                            Set-PSRepository -Name PSGallery -InstallationPolicy Trusted -ErrorAction SilentlyContinue
                            Install-PackageProvider -Name $using:packageProviderName -ErrorAction SilentlyContinue              
                            Install-PackageProvider "NuGet"  -Force -MinimumVersion 2.8 | Out-Null
                            #-ErrorAction SilentlyContinue # -RequiredVersion 2.8.5.201

                            Import-PackageProvider -Name $using:packageProviderName      

                            $using:packages | ForEach-Object -Process {
                                If(-Not (Get-Package -Name $_ -ProviderName $using:packageProviderName -ErrorAction SilentlyContinue)) 
                                {
                                    $var = $false
                                }
                            }
                        }
                        catch {
                           
                        }

                        return $var         
                    }
                GetScript = { $null }                          
            }

            $FarmTask = "[Script]DevSetup"  
         
        }
        ## END JumpBox Github Settings

        if($joinDomain){
            # wait domain is available before joinning this computer to domain
            xWaitForADDomain DscForestWait
            {
                DomainName = $DomainName
                DomainUserCredential= $DomainAdminCredential
                RetryCount = $RetryCount
                RetryIntervalSec = $RetryIntervalSec
                DependsOn = $FarmTask  
            }

            $FarmTask = "[xWaitForADDomain]DscForestWait"  
    
            # once domain is available join this computer to domain.
            Computer JoinDomain
            {
                Name       = $env:COMPUTERNAME
                DomainName = $DomainName
                Credential = $DomainAdminCredential 
                DependsOn  = $FarmTask  
            }            
            $FarmTask = "[Computer]JoinDomain"    
        }

        # Move DVD optical drive letter E to Z
        OpticalDiskDriveLetter MoveDiscDrive
        {
           DiskId      = 1
           DriveLetter = 'Z' # This value is ignored if absent
           Ensure      = 'Present'
           DependsOn  = $FarmTask  
        }

        $FarmTask = "[OpticalDiskDriveLetter]MoveDiscDrive"    

        # removes pagefile on Drive and move D drive to T and sets back page file on that drive
        Script DeletePageFile
        {
            SetScript = {
                # change C drive label to "System" from "Windows"
                $drive = Get-WmiObject win32_volume -Filter "DriveLetter = 'C:'" -ErrorAction SilentlyContinue
                $drive.Label = "System"
                $drive.put()
                
                $cpf = Set-WMIInstance -Class Win32_PageFileSetting -Arguments @{ Name = "C:\pagefile.sys"; MaximumSize = 0; } -ErrorAction SilentlyContinue

                #Get-WmiObject win32_pagefilesetting
                $pf = Get-WmiObject -Query "select * from Win32_PageFileSetting where name='D:\\pagefile.sys'" -ErrorAction SilentlyContinue                
                if($pf -ne $null) {$pf.Delete()}  
            }

            TestScript = {                                 
                $CurrentPageFile = Get-WmiObject win32_volume -Filter "DriveLetter = 'T:'" -ErrorAction SilentlyContinue 
                if($CurrentPageFile -eq $null) { return $false } else {return $true }
            }
            GetScript = { $null } 
            DependsOn  = $FarmTask       
        }

        $FarmTask = "[Script]DeletePageFile"    

        xPendingReboot Reboot1
        {
            name = "After deleting PageFile"
            DependsOn  = $FarmTask
        }
        $FarmTask = "[xPendingReboot]Reboot1"    

        # removes pagefile on Drive and move D drive to T and sets back page file on that drive
        Script DDrive
        {
           SetScript = {
              
               $drive = Get-Partition -DriveLetter "D" | Set-Partition -NewDriveLetter "T"  -ErrorAction SilentlyContinue

               $tpf = Set-WMIInstance -Class Win32_PageFileSetting -Arguments @{ Name = "T:\pagefile.sys"; MaximumSize = 0; } -ErrorAction SilentlyContinue

               $pf = Get-WmiObject -Query "select * from Win32_PageFileSetting where name='C:\\pagefile.sys'" -ErrorAction SilentlyContinue                
               if($pf -ne $null) {$pf.Delete()}  

           }

           TestScript = {                                 
                $CurrentPageFile = Get-WmiObject win32_volume -Filter "DriveLetter = 'T:'" -ErrorAction SilentlyContinue 
                if($CurrentPageFile -eq $null) { return $false } else {return $true }
           }
           GetScript = { $null } 
           DependsOn  = $FarmTask                  
           #PsDscRunAsCredential = $DomainAdminCredential

        }
        $FarmTask = "[Script]DDrive"  


        # convert DataDisks Json string to array of objects
        $DataDisks = $DataDisks | ConvertFrom-Json        

        
        if($DataDisks.Count -gt 0){
            # loop each Datadisk information and mount to a letter in object
            $count = 2 # start with "2" ad "0" and "1" is for  C  and D that comes from WindowsServer Azure image 

            # if size eq small wait only one data disk
            if($DiskSize -ne "Default") {
                # wait for disk is mounted to vm and available   
                WaitForDisk DataDisk
                {
                    DiskId = $count 
                    RetryIntervalSec = $RetryIntervalSec
                    RetryCount = $RetryCount
                    DependsOn  = $FarmTask
                }
               
                $FarmTask = "[WaitForDisk]DataDisk"               
            }
        }

        $DisksizeGB  = [int64]$DisksizeGB * 1GB
    
        foreach ($datadisk in $DataDisks)
        {
            $letter = $datadisk.letter            
            $label = $datadisk.name           
           
            $drive = Get-WmiObject win32_volume -Filter "Label = '$($label)'" -ErrorAction SilentlyContinue
            #$drive = Get-WmiObject win32_volume -Filter "DriveLetter = '$($letter):'" -ErrorAction SilentlyContinue

            #(Get-Volume -DriveLetter $datadisk.letter -ErrorAction SilentlyContinue) -ge 1
            
            if(!$drive) {
                if($DiskSize -ne "Default") {
                    # once disk number availabe, assign and format drive with all available sizes and assign a leter and label that comes from parameters.
                    if(($DataDisks.Length -1 ) -eq $DataDisks.IndexOf($datadisk))
                    {                    
                        Disk $datadisk.letter
                        {
                            FSLabel = $datadisk.name
                            DiskId = $count 
                            DriveLetter = $datadisk.letter                  
                            DependsOn  = $FarmTask
                        }
                        
                    }                
                    else {
                        Disk $datadisk.letter
                        {
                            FSLabel = $datadisk.name
                            DiskId = $count
                            DriveLetter = $datadisk.letter
                            Size = $DisksizeGB
                            DependsOn  = $FarmTask
                        }
                    }

                    $FarmTask = "[Disk]$($datadisk.letter)"

                    $DisksizeGB += 0.01GB
                }
                else{
                    # wait for disk is mounted to vm and available   
                    WaitForDisk $datadisk.name
                    {
                        DiskId = $count
                        RetryIntervalSec = $RetryIntervalSec
                        RetryCount = $RetryCount
                        DependsOn  = $FarmTask
                    }
                    $FarmTask = "[WaitForDisk]$($datadisk.name)"
                    # once disk number availabe, assign and format drive with all available sizes and assign a leter and label that comes from parameters.
                    Disk $datadisk.letter
                    {
                        FSLabel = $datadisk.name
                        DiskId = $count
                        DriveLetter = $datadisk.letter
                        DependsOn  = $FarmTask
                    }
                    $FarmTask = "[Disk]$($datadisk.letter)"
                    $count ++
                }
            }
        }  
            
        if($joinDomain)
        {
            Group AddUserAToLocalAdminGroup {
                GroupName            = 'Administrators'
                Ensure               = 'Present'
                MembersToInclude     = "$($DomainName.split('.')[0])\user_a"
                Credential           =  $DomainAdminCredential 
                #PsDscRunAsCredential =  $DomainAdminCredential
                DependsOn           = $FarmTask
            }
            $FarmTask = "[Group]AddUserAToLocalAdminGroup"
        }
         


        ## JumpBox Github Settings
        ## Clone Git Repositories
        if($env:ComputerName -eq "JumpBox" -And ($enterpriseGithubUsername) -And ($enterpriseGithubToken)) {  
            
            
            <# 
                $Repositories = @(
                    "CI.Common",
                    "CI.SharePoint",
                    "CI.OOS",
                    "CI.SQL",
                    "CI.SCOM",
                    "CI.Exchange",
                    "CI.AD-DS",
                    "CI.DHCP",
                    "CI.DNS",
                    "CI.NPS",
                    "CI.FileServices",
                    "CI.UEM",
                    "CI.Skype"
                )
            #>

            $Repositories = @("CI.Common")

            Script CloneRepositories
            {
                SetScript = {
                    try { 
                        New-Item -Path "c:\" -Name "github" -ItemType "directory" 
                        Set-Location -Path "C:\github"

                        $using:Repositories | ForEach-Object -Process { 
                            $url = "https://"
                            $url += "$($using:enterpriseGithubUsername):$($using:enterpriseGithubToken)"
                            $url += '@github.dxc.com/AdvSol/'
                            $url += $_
                            $url += '.git'
                            
                            if(-Not (Test-Path -path "c:\github\$_")) 
                            {
                                git clone $url -q
                            }
                        }

                        if(Test-Path -path "C:\github\CI.Common") 
                        {                        
                        # Imports Common CI Utilities
                        # Write-Host "Importing CI.Common Module" -ForegroundColor DarkCyan
                        if((Get-Module -Name 'CI.Common')){ Remove-Module -Name 'CI.Common' }
                        Import-Module -Name 'C:\github\CI.Common\CI.Common.psd1' -DisableNameChecking
                        Get-CIRepositories  -RepositoryRoot "C:\github" -GithubUsername "$($using:enterpriseGithubUsername)" -GithubToken "$($using:enterpriseGithubToken)"
                        #
                        }

                        if(Test-Path -path "C:\github\CI.Common\InstallPackages.ps1") 
                        {                        
                        # Imports Common CI Utilities
                        # Write-Host "Importing CI.Common Module" -ForegroundColor DarkCyan
                        if((Get-Module -Name 'CI.Common')){ Remove-Module -Name 'CI.Common' }
                        Import-Module -Name 'C:\github\CI.Common\CI.Common.psd1' -DisableNameChecking
                        # Install additional packages
                        &"C:\github\CI.Common\AzurePreBuildAdditionalPackages.ps1"
                        #
                        }
                    }
                    catch {
                        Write-Verbose "Can not colone git repositories."
                    }
                }

                TestScript = { 
                    $var = $true

                    $using:Repositories | ForEach-Object -Process { 
                        if(-Not (Test-Path -path "C:\github\$_")) 
                        {
                            $var = $false                             
                        }
                    }

                    return $var
                }
                GetScript = { $null }   
                DependsOn           = $FarmTask   
                  
            }
            $FarmTask = "[Script]CloneRepositories"   
        }
        ## END JumpBox Github Settings
        # Convert Json string to Hashtable
        
        $ConfigData | Out-File -FilePath C:\json.txt

        $ConfigData = $ConfigData | ConvertFrom-Json        
        
        ### Service Additional Settings
       
        if($ServiceName -eq "DNS")
        {
            ##  START DNS Services
            # Install DNS windows features 
            @(
                "DNS",
                "RSAT-Dns-Server"       
            ) | ForEach-Object -Process {
                    WindowsFeature "Feature-$_"
                    {
                        Ensure = "Present"
                        Name = $_                   
                    }
                    
            }
            
            $ZoneName =  $ConfigData.ZoneName
            $ZoneFile =  $ConfigData.ZoneFile
            $DynamicUpdate =  $ConfigData.DynamicUpdate
            $TransferType =  $ConfigData.TransferType
            $PrimaryServerIP = $ConfigData.PrimaryServerIP
            $PrimaryServer = $ConfigData.PrimaryServer
            $SecondaryServerIP = $ConfigData.SecondaryServerIP
            $SecondaryServer = $ConfigData.SecondaryServer

            if($ServerName -eq $PrimaryServer)
            {
                <# 
                    xDnsServerSetting DnsServerProperties
                    {
                        Name = 'DnsServerSetting'
                        ListenAddresses = '10.0.0.4'
                        IsSlave = $true
                        Forwarders = '168.63.129.16','168.63.129.18'
                        RoundRobin = $true
                        LocalNetPriority = $true
                        SecureResponses = $true
                        NoRecursion = $false
                        BindSecondaries = $false
                        StrictFileParsing = $false
                        ScavengingInterval = 168
                        LogLevel = 50393905
                    }
                #>
                # Initiate Primary Zone
                xDnsServerPrimaryZone addPrimaryZone
                {
                    Ensure        = 'Present'
                    Name          = $ZoneName
                    ZoneFile      = $ZoneFile
                    DynamicUpdate = $DynamicUpdate                    
                }
                $FarmTask = "[xDnsServerPrimaryZone]addPrimaryZone"   

                xDnsServerZoneTransfer TransferToAnyServer
                {
                    Name            = $ZoneName
                    Type            = $TransferType
                    SecondaryServer = $SecondaryServerIP
                   
                }
            
            }

            if($ServerName -eq $SecondaryServer)
            {
                ##Wait for Primary Zone
                WaitForAll PrimaryZone
                {
                    ResourceName = '[xDnsServerZoneTransfer]TransferToAnyServer'
                    NodeName = $PrimaryServer
                    RetryIntervalSec = 60
                    RetryCount = 30
                }
                # Initiate Secondary Zone
                xDnsServerSecondaryZone addSecondaryZone
                {
                    Ensure        = 'Present'
                    Name          = $ZoneName
                    MasterServers = $PrimaryServerIP
                    DependsOn = "[WaitForAll]PrimaryZone"
                }
            }
        }
        elseif ($ServiceName -eq "NPS"){
            ##  START NPS Services
            $WindowsFeatures =  $ConfigData.WindowsFeatures
            $VPNServers =  $ConfigData.VPNServers
             
            if($VPNServers -contains $ServerName) 
            {
                # Install DNS windows features
                $WindowsFeatures | ForEach-Object -Process {
                        WindowsFeature "Feature-$_"
                        {
                            Ensure = "Present"
                            Name = $_                   
                        }                                       
                }   
            }

        }
        elseif ($ServiceName -eq "SharedSQLFull")
        {
            ##  START SHARED SQL INSTALLATIONS
            # Convert Json string to Hashtable
            
        
            # $SQLConfiguration.Nodes.Where{$_.Role -eq "Primary"}       
            #
            foreach ($myPsObject in $ConfigData) {
                $ConfigDataHash = @{};            
                $myPsObject | Get-Member -MemberType *Property | % {                  $ConfigDataHash.($_.name) = $myPsObject.($_.name);              }                
                $ConfigDataHash;
                
            }

            $ConfigData =  $ConfigDataHash          
            $ConfigData | ConvertTo-Json |  Out-File -FilePath C:\ConfigData.txt
            #$ConfigData | Out-File -FilePath C:\json.txt

            	   
            $SqlAdministratorCredential = $DomainAdminCredential,
            $SqlServiceCredential       = $DomainAdminCredential,    
            $SqlAgentServiceCredential  = $DomainAdminCredential,
            
            $ServerSite | ConvertTo-Json | Out-File -FilePath C:\Nodes.txt

            $Nodes       = $ConfigData.V
            $Config      = $ConfigData.Config

            $Nodes | ConvertTo-Json | Out-File -FilePath C:\Nodes.txt

            $Node = $Nodes.Nodes.Where{$_.Name -eq $ServerName} 
            
            $Node | ConvertTo-Json | Out-File -FilePath C:\Node.txt

            $ClusterIPAddress = $Nodes.NonNodeData.ClusterIPAddress
            $ClusterName      = $Nodes.NonNodeData.ClusterName
        
            $ClusterNodes = @();

                $Nodes.Nodes.foreach({
                $ClusterNodes += $_.Name
                });

            xCredSSP CredSSPServer
            {
                Ensure = 'Present'
                Role = 'Server'
            }

            xCredSSP CredSSPClient
            {
                Ensure = 'Present'
                Role = 'Client'
                DelegateComputers = "*.$($DomainName)"
            }
                
            @(
                "Failover-clustering",            
                "RSAT-Clustering-PowerShell",
                "RSAT-Clustering-CmdInterface",
                "RSAT-Clustering-Mgmt",
                "RSAT-AD-PowerShell",
                "RSAT-DNS-Server"
            ) | ForEach-Object -Process {
                WindowsFeature "Feature-$_"
                {
                    Ensure = "Present"
                    Name = $_
                }
            }  

            if ( $Node.Role -eq 'Primary' )      
            { 
                
            WaitForAll ClusterFeature
            {
                    ResourceName = '[WindowsFeature]Feature-RSAT-Clustering-CmdInterface'
                    NodeName = $Node.Name
                    RetryCount = $RetryCount
                    RetryIntervalSec = $RetryIntervalSec
                    PsDscRunAsCredential = $DomainAdminCredential
            }
                
            Script CreateCluster
                {
                    SetScript = {
                            $ClusterService = Get-Service "ClusSvc"
                        
                        If($ClusterService) 
                            {
                                New-Cluster $using:ClusterName -Node $using:ClusterNodes -StaticAddress $using:ClusterIPAddress -NoStorage -AdministrativeAccessPoint Dns
                            }
                            #Get-Cluster -Name 'mc21'  | Add-ClusterNode -Name "VS222"
                            #Get-Cluster -Name MyCl1 | Add-ClusterNode -Name node3

                        }
                        TestScript = {  
                                        $ClusterService = Get-Service "ClusSvc"

                                        If($ClusterService) 
                                        {
                                            if($ClusterService.StartType -ne "Disabled")
                                            {
                                                if(Get-Cluster) {
                                                return $true
                                                }
                                                else{return $true}
                                            }
                                            else
                                            {
                                                return $false
                                            }                                 
                                        }
                                        else {return $true}
                        
                        }

                        GetScript = { $null }
                        DependsOn        =  '[WindowsFeature]Feature-Failover-clustering','[WindowsFeature]Feature-RSAT-Clustering-CmdInterface'
                        PsDscRunAsCredential  =  $DomainAdminCredential
                    
                    }
                }

                # Depreciated copy to local from extracted files.
                <#MountImage ISO
                {
                    ImagePath   =  $Config.SQLInstalISO
                    DriveLetter = 'S'
                    Ensure = "Present"
                    PsDscRunAsCredential = $InstallCredential  
                }

                WaitForVolume WaitForISO
                {
                    DriveLetter      = 'S'
                    RetryCount = $RetryCount
                    RetryIntervalSec = $RetryIntervalSec
                }
                #>
                # copy SQL binarias to local drive
                File DirectoryCopy
                {
                    Ensure = "Present" # Ensure the directory is Present on the target node.
                    Type = "Directory" # The default is File.
                    Recurse = $true # Recursively copy all subdirectories.
                    SourcePath = $Config.SQLInstallSource
                    DestinationPath = $Config.SQLInstallDestination            
                    Credential = $DomainAdminCredential      
                
                }

                Registry DisableIPv6
                {
                    Key       = 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip6\Parameters'
                    ValueName = 'DisabledComponents'
                    ValueData = 'ff'
                    ValueType = 'Dword'
                    Hex       = $true
                    Ensure    = 'Present'
                }
                
                Registry DisableLoopBackCheck 
                        {
                        Ensure = "Present"
                        Key = "HKLM:\System\CurrentControlSet\Control\Lsa"
                        ValueName = "DisableLoopbackCheck"
                        ValueData = "1"
                        ValueType = "Dword"
                }
                
                #endregion Install SQL Server
                Firewall SQLEngineFirewallRule
                {
                    Name         = 'SQLDatabaseEngine'
                    DisplayName  = 'SQL Server Database Engine'
                    Group        = 'SQL Server Rules'
                    Ensure       = 'Present'
                    Action       = 'Allow'
                    Enabled      = 'True'
                    Profile      = ('Domain', 'Private')
                    Direction    = 'Inbound'
                    LocalPort    = ('1433', '1434')
                    Protocol     = 'TCP'
                    Description  = 'SQL Database engine exception'
                }    
                
                #endregion Install SQL Server
                Firewall SQLEngineFailoverCluster
                {
                    Name         = 'SQLFailover'
                    DisplayName  = 'SQL Failover Sync'
                    Group        = "SQL Server Rules"
                    Ensure       = 'Present'
                    Action       = 'Allow'
                    Enabled      = 'True'
                    Profile      = ('Domain', 'Private')
                    Direction    = 'Inbound'
                    LocalPort    = ('5022', '5022')
                    Protocol     = 'TCP'
                    Description  = 'SQL Failover Port'
                }        
                
                WaitForAll Cluster
                {
                NodeName = $Nodes.Nodes.Where{$_.Role -eq "Primary"}.Name
                ResourceName = "[Script]CreateCluster"
                PsDscRunAsCredential = $SqlAdministratorCredential
                RetryCount = $RetryCount
                RetryIntervalSec = $RetryIntervalSec
                }

                if ( $Node.Role -eq 'Primary' )
                {
                    $SqlDnsPrefix       = $Nodes.NonNodeData.SqlDnsPrefix
                    $DnsServer          = $Nodes.NonNodeData.DnsServer

                    xDnsRecord TestRecord
                    {
                        Name = $SqlDnsPrefix
                        Target = $ServerIP
                        Zone = $DomainName
                        Type = "ARecord"
                        DnsServer = $DnsServer
                        Ensure = "Present"
                        PsDscRunAsCredential = $DomainAdminCredential
                    }
                } 
                
                #region Install SQL Server
                SqlSetup 'InstallDefaultInstance'
                {
                    InstanceName         = $Config.InstanceName 
                    #Features             = 'SQLENGINE,AS'
                    Features             = 'SQLENGINE,FULLTEXT,AS,RS'
                    #ProductKey           = '' 
                    SQLCollation         = 'SQL_Latin1_General_CP1_CI_AS'
                    SQLSvcAccount        = $SqlServiceCredential
                    AgtSvcAccount        = $SqlAgentServiceCredential             
                    AgtSvcStartupType    = "Automatic"
                    SqlSvcStartupType    = "Automatic"
                    SQLSysAdminAccounts  = $SqlAdministratorCredential.UserName
                    InstallSharedDir     = 'C:\Program Files\Microsoft SQL Server'
                    InstallSharedWOWDir  = 'C:\Program Files (x86)\Microsoft SQL Server'
                    InstanceDir          = 'C:\Program Files\Microsoft SQL Server'
                    InstallSQLDataDir    = 'E:\Data'
                    SQLUserDBDir         = 'E:\Data'
                    SQLUserDBLogDir      = 'F:\Logs'
                    SQLTempDBDir         = 'G:\Data'
                    SQLTempDBLogDir      = 'G:\Logs'
                    SQLBackupDir         = 'H:\Backup'              
                    SourcePath           =  $Config.SQLInstallDestination
                    UpdateEnabled        = 'False'
                    ForceReboot          = $true 
                    ASServerMode         = 'TABULAR'
                    ASConfigDir          = 'E:\MSOLAP\Config'
                    ASDataDir            = 'E:\MSOLAP\Data'
                    ASLogDir             = 'F:\MSOLAP\Log'
                    ASBackupDir          = 'H:\MSOLAP\Backup'
                    ASTempDir            = 'G:\MSOLAP\Data'
                    AsSvcStartupType     = "Automatic"
                    FTSvcAccount         =  $SqlServiceCredential
                    ASSvcAccount         =  $SqlServiceCredential
                    RSSvcAccount         =  $SqlServiceCredential
                    RsSvcStartupType     =  "Automatic"
                    BrowserSvcStartupType = "Automatic"
                    PsDscRunAsCredential = $DomainAdminCredential   
                    DependsOn         = "[File]DirectoryCopy", "[Firewall]SQLEngineFirewallRule"
                }
                
                SqlServerLogin DomainAdminLogin
                {
                    Name = "$($DomainNetbiosName)\Domain Admins"
                    LoginType = 'WindowsGroup'
                    ServerName = $ServerName
                    InstanceName = 'MSSQLSERVER' 
                    DependsOn = "[SqlSetup]InstallDefaultInstance"
                    PsDscRunAsCredential = $SqlAdministratorCredential
                }  

                SqlRS DefaultConfiguration
                {
                    InstanceName         = $Config.InstanceName 
                    DatabaseServerName   = $Node.Name
                    DatabaseInstanceName = $Config.InstanceName 
                    PsDscRunAsCredential = $DomainAdminCredential 
                    DependsOn = "[SqlSetup]InstallDefaultInstance"
                }
            
                # Adding the required service account to allow the cluster to log into SQL
                SqlServerLogin AddNTServiceClusSvc
                {
                    Ensure               = 'Present'
                    Name                 = 'NT SERVICE\ClusSvc'
                    LoginType            = 'WindowsUser'
                    ServerName           = $Node.Name
                    InstanceName         = $Config.InstanceName 
                    PsDscRunAsCredential = $SqlAdministratorCredential
                    DependsOn            = "[SqlSetup]InstallDefaultInstance", "[WindowsFeature]Feature-Failover-clustering"
                }

                # Add the required permissions to the cluster service login
                SqlServerPermission AddNTServiceClusSvcPermissions
                {
                    Ensure               = 'Present'
                ServerName           = $Node.Name
                InstanceName         = $Config.InstanceName 
                Principal            = 'NT SERVICE\ClusSvc'
                Permission           = 'AlterAnyAvailabilityGroup', 'ViewServerState'
                PsDscRunAsCredential = $SqlAdministratorCredential
                DependsOn            = '[SqlServerLogin]AddNTServiceClusSvc'
                }

                SqlAlwaysOnService EnableHADR
                {
                    Ensure               = 'Present'
                    InstanceName         = $Config.InstanceName 
                    ServerName           = $Node.Name
                    PsDscRunAsCredential = $SqlAdministratorCredential
                    DependsOn = "[SqlSetup]InstallDefaultInstance",  "[WindowsFeature]Feature-Failover-clustering",  "[WaitForAll]Cluster" 
                }

                # Create a DatabaseMirroring endpoint
                SqlServerEndpoint HADREndpoint
                {
                    DependsOn             = "[SqlSetup]InstallDefaultInstance", "[SqlAlwaysOnService]EnableHADR"
                    EndPointName          = 'HADR'
                    Ensure                = 'Present'
                    Port                  = 5022
                    ServerName            = $Node.Name
                    InstanceName          = $Config.InstanceName 
                    PsDscRunAsCredential  = $SqlAdministratorCredential
                }

                # Add SQL Service accounts to permissions for endpoint for Endpoints for HADR
                # required if used a service accounts 
                <# 
                SqlServerEndpointPermission EndpointPermission
                {
                    Ensure               = 'Present'
                    InstanceName         = $ConfigurationData.NonNodeData.Database.InstanceName            
                    ServerName           = $Node.NodeName           
                    Name                 = 'HADR'
                    Principal            = $Accounts["SqlServiceCredential"].UserName
                    DependsOn = @(
                                "[SqlServerEndpoint]HADREndpoint"
                    )
                }
                #>


                <#
                # install Microsoft SQL Server Management Studio
                Package SQLStudio
                {
                        Ensure = "Present"   
                        Name = "Microsoft SQL Server Management Studio"
                        Path = $Config.SQLManagementStudio2016Path          
                        ProductId = $Config.SQLManagementStudio2016ProductId
                        Arguments = "/install /passive /norestart"
                        PsDscRunAsCredential = $SqlAdministratorCredential
                        #LogPath = [string] 
                        #DependsOn = "[SqlSetup]InstallDefaultInstance"            
                }
                #>

                if ( $Node.Role -eq 'Primary' )
                {    
                    <#
                    SqlDatabase CreateDatabase1
                    {
                        Ensure       = 'Present'
                        Name         = "TestDB1"
                        ServerName   = $Node.Name
                        InstanceName = $Config.InstanceName
                        PsDscRunAsCredential = $SqlAdministratorCredential
                        DependsOn    = "[SqlSetup]InstallDefaultInstance"
                    }

                    SqlDatabase CreateDatabase2
                    {
                        Ensure       = 'Present'
                        Name         = "TestDB2"
                        ServerName   = $Node.Name
                        InstanceName = $Config.InstanceName
                        PsDscRunAsCredential = $SqlAdministratorCredential
                        DependsOn    = "[SqlSetup]InstallDefaultInstance"
                    }

                    SqlAG AddTestAG
                    {
                        Ensure               = 'Present'
                        Name                 = 'TestAG'
                        InstanceName         = $Config.InstanceName
                        ServerName           = $Node.Name                
                        AvailabilityMode              = "SynchronousCommit"
                        BackupPriority                = 50
                        ConnectionModeInPrimaryRole   = "AllowAllConnections"
                        ConnectionModeInSecondaryRole = "AllowAllConnections"
                        FailoverMode                  = "Automatic"
                        EndpointHostName              = $Node.Name
                        DependsOn            = '[SqlAlwaysOnService]EnableHADR', '[SqlServerEndpoint]HADREndpoint', '[SqlServerPermission]AddNTServiceClusSvcPermissions'
                        PsDscRunAsCredential = $SqlAdministratorCredential
                    }  
                    #>               
                }

                if ( $Node.Role -eq 'Secondary' ) 
                {
                    #Secondary
                    <#
                    SqlWaitForAG WaitForAG
                    {
                        Name                  = 'TestAG'
                        RetryCount = $RetryCount
                        RetryIntervalSec = $RetryIntervalSec
                        DependsOn             =  "[SqlSetup]InstallDefaultInstance", "[SqlAlwaysOnService]EnableHADR"
                    }

                        # Add the availability group replica to the availability group
                    SqlAGReplica AddReplica
                    {
                        Ensure                        = 'Present'
                        Name                          = $Node.Name
                        AvailabilityGroupName         = $Config.AvailabilityGroupName 
                        ServerName                    = $Node.Name
                        InstanceName                  = $Config.InstanceName 
                        ProcessOnlyOnActiveNode       = $true
                        PrimaryReplicaServerName      = $Nodes.Nodes.Where{$_.Role -eq "Primary"}.Name
                        PrimaryReplicaInstanceName    = $Config.InstanceName 
                        
                        AvailabilityMode              = "SynchronousCommit"
                        BackupPriority                = 50
                        ConnectionModeInPrimaryRole   = "AllowAllConnections"
                        ConnectionModeInSecondaryRole = "AllowAllConnections"
                        FailoverMode                  = "Automatic"
                        EndpointHostName              = $Node.Name
                        DependsOn                     = '[SqlAlwaysOnService]EnableHADR', "[SqlWaitForAG]WaitForAG"
                        PsDscRunAsCredential          = $SqlAdministratorCredential
                    }
                    #>
                }

                if ( $Node.Role -eq 'Primary' )
                {
                    <#
                        WaitForAll Replica
                        {
                            ResourceName                = '[SqlAGReplica]AddReplica'
                            NodeName                    = $Nodes.Nodes.Where{$_.Role -eq "Secondary"}.Name
                            RetryCount                  = $RetryCount
                            RetryIntervalSec            = $RetryIntervalSec
                            PsDscRunAsCredential        = $SqlAdministratorCredential
                        }

                    SqlAGDatabase TestAGDatabaseMemberships
                        {
                            Ensure                      = 'Present'
                            AvailabilityGroupName       = $Config.AvailabilityGroupName 
                            BackupPath                  = $Config.SQLAGBackup
                            DatabaseName                = 'TestDB*'
                            InstanceName                = $Config.InstanceName 
                            ServerName                  = $Node.Name              
                            #ProcessOnlyOnActiveNode = $true
                            PsDscRunAsCredential        = $SqlAdministratorCredential
                            DependsOn                   = "[SqlAG]AddTestAG", "[SqlAlwaysOnService]EnableHADR", "[WaitForAll]Replica"
                        }    
                        #>
                }

                  
        }
    }
}