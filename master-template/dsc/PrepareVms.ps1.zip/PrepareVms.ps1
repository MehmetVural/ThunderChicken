﻿configuration PrepareVms
{
   param
   (
        [String]$DiskSize = "Small-4GB",
        [String]$DisksizeGB = 4,

        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [String]$DNSServer,  
        
        [string]$ServiceName,
        [string]$ServerName,        
        [string]$ConfigData,   

        [Parameter(Mandatory=$true)]
		[ValidateNotNullorEmpty()]
        [PSCredential]$DomainAdminCredential,     
        

        [string]$DataDisks,

        [Parameter()]		
        $enterpriseGithubUsername,
        
        [Parameter()]        
        $enterpriseGithubToken,

        [Parameter(Mandatory=$true)]
        [Int]$RetryCount,

        [Parameter(Mandatory=$true)]
        [Int]$RetryIntervalSec,

        [Boolean]$RebootNodeIfNeeded = $true,
        [String]$ActionAfterReboot = "ContinueConfiguration",
        [String]$ConfigurationModeFrequencyMins = 15,
        [String]$ConfigurationMode = "ApplyAndAutoCorrect",
        [String]$RefreshMode = "Push",
        [String]$RefreshFrequencyMins  = 30
    )

    # import DSC modules 
    Import-DscResource -ModuleName xActiveDirectory
    Import-DscResource -ModuleName ComputerManagementDsc  
    Import-DscResource -ModuleName xCredSSP
    Import-DSCResource -ModuleName StorageDsc
    Import-DscResource -ModuleName xPendingReboot
    Import-DscResource -ModuleName NetworkingDsc
    Import-DscResource -ModuleName xDnsServer
    Import-DscResource -ModuleName PSDesiredStateConfiguration

    # get network adapter interface name 
    $Interface=Get-NetAdapter|Where Name -Like "Ethernet*"|Select-Object -First 1
    $InterfaceAlias=$($Interface.Name)
    
    Node localhost
    {  
        # set local configuratiom manager settings 
        LocalConfigurationManager
        {
            RebootNodeIfNeeded = $RebootNodeIfNeeded
            ActionAfterReboot = $ActionAfterReboot            
            ConfigurationModeFrequencyMins = $ConfigurationModeFrequencyMins
            ConfigurationMode = $ConfigurationMode
            RefreshMode = $RefreshMode
            RefreshFrequencyMins = $RefreshFrequencyMins            
        }

        xCredSSP CredSSPServer
        {
            Ensure = 'Present'
            Role = 'Server'
        }

        xCredSSP CredSSPClient
        {
            Ensure = 'Present'
            Role = 'Client'
            DelegateComputers = '*.Domain.com'
        }

         # change DNS server address to subnet DNS address
        DnsServerAddress  DnsServerAddress
        {
             Address        = $DNSServer
             InterfaceAlias = $InterfaceAlias
             AddressFamily  = 'IPv4'                  
        }       
 
        ## JumpBox Settings
        #### if Workstation Aka JumbBox         
        if($env:ComputerName -eq "JumpBox") {

            # install RSAT tools  for jumbBoox            
            @(
                "RSAT-ADDS-Tools" ,
                "RSAT-AD-PowerShell",
                "RSAT-DNS-Server"                                       
            ) | ForEach-Object -Process {
               WindowsFeature "Feature-$_"
               {
                   Ensure = "Present"
                   Name = $_
                   
               }
            }       

            $packages = @(
                "vscode",
                #"nodejs",
                "git",
                "Git-Credential-Manager-for-Windows",
                "poshgit",
                "pester",
                "vscode-powershell",
                "googlechrome"
                 #,"sql-server-management-studio"
            )

           $packageProviderName = "ChocolateyGet"
           Script DevSetup
           {
               SetScript = {

               Set-PSRepository -Name PSGallery -InstallationPolicy Trusted -ErrorAction SilentlyContinue
               Install-PackageProvider -Name $using:packageProviderName -ErrorAction SilentlyContinue              
               Install-PackageProvider -Name NuGet -Force -ErrorAction SilentlyContinue # -RequiredVersion 2.8.5.201
                
               Import-PackageProvider -Name $using:packageProviderName              
                
               $using:packages | ForEach-Object -Process {
                    If(-Not (Get-Package -Name $_ -ProviderName $using:packageProviderName -ErrorAction SilentlyContinue)) 
                    {                        
                       Install-Package -Name $_ -ProviderName $using:packageProviderName -Confirm:$false -Force
                    }
                                       
               }
           }
    
           TestScript = {                     
                $var = $true
                
                Set-PSRepository -Name PSGallery -InstallationPolicy Trusted -ErrorAction SilentlyContinue
                Install-PackageProvider -Name $using:packageProviderName -ErrorAction SilentlyContinue              
                Install-PackageProvider -Name NuGet -Force -ErrorAction SilentlyContinue # -RequiredVersion 2.8.5.201

                Import-PackageProvider -Name $using:packageProviderName      

                $using:packages | ForEach-Object -Process {
                    If(-Not (Get-Package -Name $_ -ProviderName $using:packageProviderName -ErrorAction SilentlyContinue)) 
                    {
                        $var = $false
                    }
                }

                return $var         
            }
           GetScript = { $null }               
           }
        }
        ## END JumpBox Github Settings

        # wait domain is available before joinning this computer to domain
        xWaitForADDomain DscForestWait
        {
             DomainName = $DomainName
             DomainUserCredential= $DomainAdminCredential
             RetryCount = $RetryCount
             RetryIntervalSec = $RetryIntervalSec
             DependsOn  = "[DnsServerAddress]DnsServerAddress"
        }
 
        # once domain is available join this computer to domain.
        Computer JoinDomain
        {
             Name       = $env:COMPUTERNAME
             DomainName = $DomainName
             Credential = $DomainAdminCredential 
             DependsOn  = "[xWaitForADDomain]DscForestWait"
        }
        
        # Move DVD optical drive letter E to Z
        OpticalDiskDriveLetter MoveDiscDrive
        {
           DiskId      = 1
           DriveLetter = 'Z' # This value is ignored if absent
           Ensure      = 'Present'
           DependsOn = "[Computer]JoinDomain"
        }

        # removes pagefile on Drive and move D drive to T and sets back page file on that drive
        Script DeletePageFile
        {
            SetScript = {
                # change C drive label to "System" from "Windows"
                $drive = Get-WmiObject win32_volume -Filter "DriveLetter = 'C:'" -ErrorAction SilentlyContinue
                $drive.Label = "System"
                $drive.put()
                
                $cpf = Set-WMIInstance -Class Win32_PageFileSetting -Arguments @{ Name = "C:\pagefile.sys"; MaximumSize = 0; } -ErrorAction SilentlyContinue

                #Get-WmiObject win32_pagefilesetting
                $pf = Get-WmiObject -Query "select * from Win32_PageFileSetting where name='D:\\pagefile.sys'" -ErrorAction SilentlyContinue                
                if($pf -ne $null) {$pf.Delete()}  
            }

            TestScript = {                                 
                $CurrentPageFile = Get-WmiObject win32_volume -Filter "DriveLetter = 'T:'" -ErrorAction SilentlyContinue 
                if($CurrentPageFile -eq $null) { return $false } else {return $true }
            }
            GetScript = { $null } 
            DependsOn = "[OpticalDiskDriveLetter]MoveDiscDrive"        
        }

        xPendingReboot Reboot1
        {
            name = "After deleting PageFile"
            DependsOn = "[Script]DeletePageFile"             
        }

        # removes pagefile on Drive and move D drive to T and sets back page file on that drive
        Script DDrive
        {
           SetScript = {
              
               $drive = Get-Partition -DriveLetter "D" | Set-Partition -NewDriveLetter "T"  -ErrorAction SilentlyContinue

               $tpf = Set-WMIInstance -Class Win32_PageFileSetting -Arguments @{ Name = "T:\pagefile.sys"; MaximumSize = 0; } -ErrorAction SilentlyContinue

               $pf = Get-WmiObject -Query "select * from Win32_PageFileSetting where name='C:\\pagefile.sys'" -ErrorAction SilentlyContinue                
               if($pf -ne $null) {$pf.Delete()}  

           }

           TestScript = {                                 
                $CurrentPageFile = Get-WmiObject win32_volume -Filter "DriveLetter = 'T:'" -ErrorAction SilentlyContinue 
                if($CurrentPageFile -eq $null) { return $false } else {return $true }
           }
           GetScript = { $null } 
           DependsOn = "[xPendingReboot]Reboot1"                     
           PsDscRunAsCredential = $DomainAdminCredential

        }

        # convert DataDisks Json string to array of objects
        $DataDisks = $DataDisks | ConvertFrom-Json        

        
        if($DataDisks.Count -gt 0){
            # loop each Datadisk information and mount to a letter in object
            $count = 2 # start with "2" ad "0" and "1" is for  C  and D that comes from WindowsServer Azure image 

            # if size eq small wait only one data disk
            if($DiskSize -ne "Default") {
                # wait for disk is mounted to vm and available   
                WaitForDisk DataDisk
                {
                    DiskId = $count 
                    RetryIntervalSec = $RetryIntervalSec
                    RetryCount = $RetryCount
                    DependsOn  ="[OpticalDiskDriveLetter]MoveDiscDrive", "[Script]DDrive"
                }

                $DependsOn = "[WaitForDisk]DataDisk"
            }
        }

        $DisksizeGB  = [int64]$DisksizeGB * 1GB
    
        foreach ($datadisk in $DataDisks)
        {
            $letter = $datadisk.letter            
            $label = $datadisk.name           
           
            $drive = Get-WmiObject win32_volume -Filter "Label = '$($label)'" -ErrorAction SilentlyContinue
            #$drive = Get-WmiObject win32_volume -Filter "DriveLetter = '$($letter):'" -ErrorAction SilentlyContinue

            #(Get-Volume -DriveLetter $datadisk.letter -ErrorAction SilentlyContinue) -ge 1
            
            if(!$drive) {
                if($DiskSize -ne "Default") {
                    # once disk number availabe, assign and format drive with all available sizes and assign a leter and label that comes from parameters.
                    if(($DataDisks.Length -1 ) -eq $DataDisks.IndexOf($datadisk))
                    {                    
                        Disk $datadisk.letter
                        {
                            FSLabel = $datadisk.name
                            DiskId = $count 
                            DriveLetter = $datadisk.letter                  
                            DependsOn = $DependsOn
                        }
                    }                
                    else {
                        Disk $datadisk.letter
                        {
                            FSLabel = $datadisk.name
                            DiskId = $count
                            DriveLetter = $datadisk.letter
                            Size = $DisksizeGB
                            DependsOn = $DependsOn
                        }
                    }
                    $DependsOn = "[Disk]" + $datadisk.letter

                    $DisksizeGB += 0.01GB
                }
                else{
                    # wait for disk is mounted to vm and available   
                    WaitForDisk $datadisk.name
                    {
                        DiskId = $count
                        RetryIntervalSec = $RetryIntervalSec
                        RetryCount = $RetryCount
                        DependsOn  ="[OpticalDiskDriveLetter]MoveDiscDrive", "[Script]DDrive"
                    }
                    # once disk number availabe, assign and format drive with all available sizes and assign a leter and label that comes from parameters.
                    Disk $datadisk.letter
                    {
                        FSLabel = $datadisk.name
                        DiskId = $count
                        DriveLetter = $datadisk.letter
                        DependsOn = "[WaitForDisk]"+$datadisk.name
                    }
                    $count ++
                }
            }
        }   
        
        ## JumpBox Github Settings
        ## Clone Git Repositories
        if($env:ComputerName -eq "JumpBox" -And ($enterpriseGithubUsername) -And ($enterpriseGithubToken)) {        
            <#
                $Repositories = @(
                    "CI.Common",
                    "CI.SharePoint",
                    "CI.OOS",
                    "CI.SQL",
                    "CI.SCOM",
                    "CI.Exchange",
                    "CI.AD-DS",
                    "CI.DHCP",
                    "CI.DNS",
                    "CI.NPS",
                    "CI.FileServices",
                    "CI.UEM",
                    "CI.Skype"
                )
            #>

            $Repositories = @("CI.Common")

            Script CloneRepositories
            {
                SetScript = {
                    
                    New-Item -Path "c:\" -Name "github" -ItemType "directory" 
                    Set-Location -Path "C:\github"

                    $using:Repositories | ForEach-Object -Process { 
                        $url = "https://"
                        $url += "$($using:enterpriseGithubUsername):$($using:enterpriseGithubToken)"
                        $url += '@github.dxc.com/AdvSol/'
                        $url += $_
                        $url += '.git'
                        
                        if(-Not (Test-Path -path "c:\github\$_")) 
                        {
                            git clone $url -q
                        }
                    }

                    if(Test-Path -path "C:\github\CI.Common") 
                    {                        
                       # Imports Common CI Utilities
                       # Write-Host "Importing CI.Common Module" -ForegroundColor DarkCyan
                       if((Get-Module -Name 'CI.Common')){ Remove-Module -Name 'CI.Common' }
                       Import-Module -Name 'C:\github\CI.Common\CI.Common.psd1' -DisableNameChecking
                       Get-CIRepositories  -RepositoryRoot "C:\github" -GithubUsername "$($using:enterpriseGithubUsername)" -GithubToken "$($using:enterpriseGithubToken)"
                       #
                    }
                }

                TestScript = { 
                    $var = $true 
                    $using:Repositories | ForEach-Object -Process { 
                        if(-Not (Test-Path -path "C:\github\$_")) 
                        {
                            $var = $false                             
                        }
                    }

                    return $var
                }
                GetScript = { $null }               
            }
        } 
        ## END JumpBox Github Settings

        ## DNS ##
        ### Service Additional Settings
        if($ServiceName -eq "DNS")
        {
            # Install DNS windows features 
            @(
                "DNS",
                "RSAT-Dns-Server"
            ) | ForEach-Object -Process {
                    WindowsFeature "Feature-$_"
                    {
                        Ensure = "Present"
                        Name = $_                    
                    }
            }
            
            $ZoneName = "Split.com"
            $ZoneFile = "Split.com.dns"
            $DynamicUpdate = "NonsecureAndSecure"
            $TransferType = 'Specific'

            if($ServerName -eq "KH178")
            {
                # Initiate Primary Zone
                xDnsServerPrimaryZone addPrimaryZone
                {
                    Ensure        = 'Present'
                    Name          = $ZoneName
                    ZoneFile      = $ZoneFile
                    DynamicUpdate = $DynamicUpdate
                }

                xDnsServerZoneTransfer TransferToAnyServer
                {
                    Name = $ZoneName
                    Type = $TransferType
                    SecondaryServer = "CH178.domain.com"
                }

            }

            if($ServerName -eq "CH178")
            {
                ##Wait for Primary Zone
                WaitForAll PrimaryZone
                {
                    ResourceName = '[xDnsServerZoneTransfer]TransferToAnyServer'
                    NodeName = "KH178.domain.com"
                    RetryIntervalSec = 600
                    RetryCount = 30
                }
                # Initiate Secondary Zone
                xDnsServerSecondaryZone addSecondaryZone
                {
                    Ensure        = 'Present'
                    Name          = $ZoneName
                    MasterServers = "CH178.domain.com"
                    DependsOn = "[WaitForAll]PrimaryZone"
                }
            }
        }
        ## END DNS ##
   }
}