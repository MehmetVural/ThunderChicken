Configuration ConfigureSCOM { 
    param
    (
        [Parameter(Mandatory = $true)]
        [ValidateNotNullorEmpty()]
        [System.Management.Automation.PSCredential]
        $InstallCredential,

        [Parameter(Mandatory=$true)]
		[ValidateNotNullorEmpty()]
        [PSCredential]$DomainAdminCredential,

        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]    
        [String]$Nodes,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]    
        [String]$Config,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]    
        [String]$ServerName,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]    
        [String]$ServerIP, 

        [Parameter(Mandatory=$true)]
        [Int]$RetryCount,

        [Parameter(Mandatory=$true)]
        [Int]$RetryIntervalSec,     

        [Boolean]$RebootNodeIfNeeded = $true,
        [String]$ActionAfterReboot = "ContinueConfiguration",
        [String]$ConfigurationModeFrequencyMins = 15,
        [String]$ConfigurationMode = "ApplyAndAutoCorrect",
        [String]$RefreshMode = "Push",
        [String]$RefreshFrequencyMins  = 30

    )  

    Import-DscResource -ModuleName SqlServerDsc
    Import-DscResource -ModuleName StorageDsc
    Import-DscResource -ModuleName xCredSSP
    Import-DscResource -Module xSCOM -ModuleVersion "1.3.3.1"
    Import-DscResource -ModuleName NetworkingDsc
    Import-DscResource -Module xDnsServer
    Import-DscResource -ModuleName PSDesiredStateConfiguration

    Node Localhost {
        
         # set local configuratiom manager settings 
         LocalConfigurationManager
         {
             RebootNodeIfNeeded = $RebootNodeIfNeeded
             ActionAfterReboot = $ActionAfterReboot            
             ConfigurationModeFrequencyMins = $ConfigurationModeFrequencyMins
             ConfigurationMode = $ConfigurationMode
             RefreshMode = $RefreshMode
             RefreshFrequencyMins = $RefreshFrequencyMins            
         }

        # Convert Json string to Hashtable
        $Nodes = $Nodes | ConvertFrom-Json 
        $Config = $Config | ConvertFrom-Json 

        $Node = $Nodes.Nodes.Where{$_.Name -eq $ServerName} 

        xCredSSP CredSSPServer
        {
           Ensure = 'Present'
           Role = 'Server'
        }

        xCredSSP CredSSPClient
        {
           Ensure = 'Present'
           Role = 'Client'
           DelegateComputers = '*.Domain.com'
        }

        @(
            "Web-WebServer",
            "Web-Request-Monitor",
            "Web-Windows-Auth",
            "Web-Asp-Net",
            "Web-Asp-Net45",
            "NET-WCF-HTTP-Activation45",
            "Web-Mgmt-Console",
            "Web-Metabase"
        ) | ForEach-Object -Process {
            WindowsFeature "Feature-$_"
            {
                Ensure = "Present"
                Name = $_
            }
        }

        @(            
            "RSAT-AD-PowerShell",
            "RSAT-DNS-Server"
        ) | ForEach-Object -Process {
            WindowsFeature "Feature-$_"
            {
                Ensure = "Present"
                Name = $_
            }
        }  

        # copy SCOM binarias to local drive
        File DirectoryCopy
        {
            Ensure = "Present" # Ensure the directory is Present on the target node.
            Type = "Directory" # The default is File.
            Recurse = $true # Recursively copy all subdirectories.
            SourcePath = $Config.SCOMFolder
            DestinationPath = "C:\INSTALL\SCOM2016"
            MatchSource  = $true # Matches source to destination
            Credential = $InstallCredential         
        }

        # Prerequisties for SCOM report viewing
        Package "SQLServer2012SystemCLRTypes"
        {
            Ensure = "Present"
            Name = "Microsoft System CLR Types for SQL Server 2014"
            ProductId = $Config.SysClrTypesProductID
            Path = "C:\INSTALL\SCOM2016$($Config.SQLSysClrTypesSource)" 
            Arguments = "ALLUSERS=2"
            PsDscRunAsCredential = $InstallCredential
            DependsOn = "[File]DirectoryCopy"
        }

        Package "ReportViewer2012Redistributable"
        {
            Ensure = "Present"
            Name = "Microsoft Report Viewer 2015 Runtime"
            ProductID = $Config.ReportViewerProductID
            Path = "C:\INSTALL\SCOM2016$($Config.ReportViewerSource)" 
            Arguments = "ALLUSERS=2"
            PsDscRunAsCredential = $InstallCredential
            DependsOn = "[File]DirectoryCopy", "[Package]SQLServer2012SystemCLRTypes"
        }

        # Add service accounts to admins on Management Servers        
        # Group "Administrators"
        # {
        #    GroupName = "Administrators"
        #    MembersToInclude = @(
        #    Node.SystemCenter2012OperationsManagerActionAccount.UserName,
        #    $Node.SystemCenter2012OperationsManagerDASAccount.UserName
        # )     

        WaitForAll "SQLServer"
        {
            NodeName = $Nodes.NonNodeData.SqlServerPrimary 
            ResourceName = "[SqlAlwaysOnService]EnableHADR"
            PsDscRunAsCredential = $InstallCredential
            RetryCount = $RetryCount
            RetryIntervalSec = $RetryIntervalSec
            DependsOn = @(
                             "[File]DirectoryCopy",
                            "[Package]SQLServer2012SystemCLRTypes",
                            "[Package]ReportViewer2012Redistributable"
                  )
            
        }

        if (  $Node.Role -eq 'Primary' )
        {
            # Install first Management Server
            xSCOMManagementServerSetup "OMMS"
            { 
               Ensure = "Present"
               SourcePath = "C:\INSTALL\SCOM2016$($Config.SCOMSourcePath)" 
               
               SourceFolder = ""
               SetupCredential = $InstallCredential
               #ProductKey = ""      
               ManagementGroupName = $Nodes.NonNodeData.ManagementGroupName
               FirstManagementServer = $true
               ActionAccount = $InstallCredential
               DASAccount = $InstallCredential
               DataReader = $InstallCredential
               DataWriter = $InstallCredential
               SqlServerInstance = $Nodes.NonNodeData.SqlServerInstance
               #DatabaseName = "SCOMManager"
               #DatabaseSize = 100
               DwSqlServerInstance = $Nodes.NonNodeData.DwSqlServerInstance
               #DwDatabaseName = $Node.SqlDWDatabase
               #DwDatabaseSize = $Node.DwDatabaseSize
               PsDscRunAsCredential = $InstallCredential               
               DependsOn = @(
                             "[File]DirectoryCopy",
                             "[WaitForAll]SQLServer"
                  )
            }
        }

        if ( $Node.Role -eq 'Secondary' )
        {
            WaitForAll "OMMS"
            {
                NodeName = $Nodes.Nodes.Where{$_.Role -eq "Primary"}.Name
                ResourceName = "[xSCOMManagementServerSetup]OMMS"
                PsDscRunAsCredential = $InstallCredential
                RetryCount = $RetryCount
                RetryIntervalSec = $RetryIntervalSec
            }

            # Install additional Management Servers
            xSCOMManagementServerSetup "OMMS"
            {               
               DependsOn = @(
                            "[WaitForAll]OMMS",
                            "[Package]SQLServer2012SystemCLRTypes",
                            "[Package]ReportViewer2012Redistributable"
                )
               
               Ensure = "Present"
               SourcePath = "C:\INSTALL\SCOM2016$($Config.SCOMSourcePath)" 
               SourceFolder = ""
               SetupCredential = $InstallCredential
               ManagementGroupName =  $Nodes.NonNodeData.ManagementGroupName
               FirstManagementServer = $false
               ActionAccount = $InstallCredential
               DASAccount = $InstallCredential
               DataReader = $InstallCredential
               DataWriter = $InstallCredential
               SqlServerInstance = $Nodes.NonNodeData.SqlServerInstance
               DwSqlServerInstance = $Nodes.NonNodeData.DwSqlServerInstance
            }
        }

        xSCOMConsoleSetup "OMC"
        {
              DependsOn = @(
                        "[Package]SQLServer2012SystemCLRTypes",
                        "[Package]ReportViewer2012Redistributable",
                        "[xSCOMManagementServerSetup]OMMS"
              )
              Ensure = "Present"
              SourcePath = "C:\INSTALL\SCOM2016$($Config.SCOMSourcePath)" 
               SourceFolder = ""
              SetupCredential = $InstallCredential
              PsDscRunAsCredential = $InstallCredential
        }

        #xSCOMReportingServerSetup "OMRS"
        #{
        #    DependsOn = "[xSCOMManagementServerSetup]OMMS"
        #    Ensure = "Present"
        #    SourcePath = $Config.SCOMSourcePath
        #    SourceFolder = ""
        #    SetupCredential = $InstallCredential
        #    ManagementServer = $Node.Name 
        #    SRSInstance = $Config.SRSInstance
        #    DataReader = $InstallCredential
        #    PsDscRunAsCredential = $InstallCredential
        #}

        xSCOMWebConsoleServerSetup "OMWC"
        {
            DependsOn = @(
                        "[Package]SQLServer2012SystemCLRTypes",
                        "[Package]ReportViewer2012Redistributable",
                        "[xSCOMManagementServerSetup]OMMS"
              )
            Ensure = "Present"
            SourcePath = "C:\INSTALL\SCOM2016$($Config.SCOMSourcePath)"
            SourceFolder = ""
            SetupCredential = $InstallCredential
            ManagementServer = $Node.Name
            PsDscRunAsCredential = $InstallCredential
        }

        if (  $Node.Role -eq 'Primary' )
        {
            $DnsPrefix       = $Nodes.NonNodeData.DnsPrefix
            $DnsServer          = $Nodes.NonNodeData.DnsServer

            xDnsRecord webScomDns
            {
                Name = $DnsPrefix
                Target = $ServerIP
                Zone = $DomainName
                Type = "ARecord"
                DnsServer = $DnsServer
                Ensure = "Present"
                PsDscRunAsCredential = $DomainAdminCredential
            }
          
            
            SqlAG AddSCOMAG
            {
                 Ensure               = 'Present'
                 Name                 = $Config.SqlServerAG 
                 InstanceName         = $Config.InstanceName 
                 ServerName           = $Nodes.NonNodeData.SqlServerPrimary                
                 AvailabilityMode              = "SynchronousCommit"
                 BackupPriority                = 50
                 ConnectionModeInPrimaryRole   = "AllowAllConnections"
                 ConnectionModeInSecondaryRole = "AllowAllConnections"
                 FailoverMode                  = "Automatic"
                 EndpointHostName              = $Nodes.NonNodeData.SqlServerPrimary                 
                 PsDscRunAsCredential = $InstallCredential
                 DependsOn = "[xSCOMWebConsoleServerSetup]OMWC"
                 
            }

            SqlAGReplica AddReplicaSCOM
            {
               Ensure                        = 'Present'
               Name                          = $Nodes.NonNodeData.SqlServerSecondary
               AvailabilityGroupName         = $Config.SqlServerAG 
               ServerName                    = $Nodes.NonNodeData.SqlServerSecondary
               InstanceName                  = $Config.InstanceName 
               ProcessOnlyOnActiveNode       = $false
               PrimaryReplicaServerName      = $Nodes.NonNodeData.SqlServerPrimary
               PrimaryReplicaInstanceName    = $Config.InstanceName 
                 
               AvailabilityMode              = "SynchronousCommit"
               BackupPriority                = 50
               ConnectionModeInPrimaryRole   = "AllowAllConnections"
               ConnectionModeInSecondaryRole = "AllowAllConnections"
               FailoverMode                  = "Automatic"
               EndpointHostName              = $Nodes.NonNodeData.SqlServerSecondary            
               PsDscRunAsCredential          = $InstallCredential
               DependsOn = "[SqlAG]AddSCOMAG"
           }

           SqlDatabaseRecoveryModel OperationsManager
           {
                Name                 = 'OperationsManager'
                RecoveryModel        = 'Full'
                ServerName           = $Nodes.NonNodeData.SqlServerPrimary
                InstanceName         = $Config.InstanceName
                PsDscRunAsCredential = $InstallCredential
                DependsOn = "[SqlAGReplica]AddReplicaSCOM"
           }

           SqlDatabaseRecoveryModel OperationsManagerDW
           {
               Name                 = 'OperationsManagerDW'
               RecoveryModel        = 'Full'
               ServerName           = $Nodes.NonNodeData.SqlServerPrimary
               InstanceName         = $Config.InstanceName
               PsDscRunAsCredential = $InstallCredential
               DependsOn = "[SqlDatabaseRecoveryModel]OperationsManager"
           }

           SqlAGDatabase Membership
           {
              Ensure                  = 'Present'
              AvailabilityGroupName   = $Config.SqlServerAG 
              BackupPath              = $Config.SQLAGBackup
              DatabaseName            = 'OperationsManager*'
               InstanceName            = $Config.InstanceName
               ServerName              =  $Nodes.NonNodeData.SqlServerPrimary
               #ProcessOnlyOnActiveNode = $true
               PsDscRunAsCredential    = $InstallCredential 
               DependsOn = @(
                "[SqlDatabaseRecoveryModel]OperationsManager",
                "[SqlDatabaseRecoveryModel]OperationsManagerDW"
                   )
            }
        }
        
        <#
        xSCOMManagementPack sqlpack
        {
           Name= "SQL 2016 Management Pack"
           SCOMAdminCredential = $InstallCredential
           SourcePath = "C:\"
           SourceFolder = "\SCOM"
           SourceFile = "SQLServer2016MP.msi"
           PsDscRunAsCredential = $InstallCredential        
        }

        $BasePath = "\\VD201\Share\SCOM\MPFiles\"
        $MPList = Get-ChildItem $BasePath -Recurse -Name "*mp*"
                
        foreach ($MP in $MPList) {           
           $ManagementPack = $BasePath + $MP
           Write-Host $ManagementPack 
           If (Test-Path ("$ManagementPack"))
                  {Import-SCManagementPack "$ManagementPack"}
        }

        install Microsoft SQL Server Management Studio Management Pack for System Operation Center 2016 
        Package SQLmanagementPack
        {
           Ensure = "Present"   
           Name = "Microsoft System Center Management Pack for SQL Server 2016"
           Path = $Config.SQL2016ManagedPack          
           ProductId = $Config.SQL2016ManagedPackProductID
           Arguments = "/quiet /norestart"
           PsDscRunAsCredential = $InstallCredential
            LogPath = [string] 
           DependsOn = "[xSCOMManagementServerSetup]OMMS"            
        }  
       #>      
    }
}
 